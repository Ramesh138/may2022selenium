package com.equifax.ews.I9RescueServiceUtilities;

import lombok.experimental.UtilityClass;

@UtilityClass
public class I9ConsolidatorRescueCollectionConstants {

    /**
     * I9 Consolidator Rescue collection searchable field constants by considering reusability.
     */
    @UtilityClass
    public static class SearchableField {

        public static final String EMPLOYER_ID = "employerIdentifier";
        public static final String LOCATION_ID = "locationIdentifier";
        public static final String STATUS = "status";
        public static final String BATCH_IDENTIFIER = "batchIdentifier";
    }

    /**
     * I9 Consolidator Rescue collection searchable field value constants by considering reusability.
     */
    @UtilityClass
    public static class SearchableFieldValue {

        public static final String FAILED = "FAIL";
        public static final String CLOSED = "CLOSED";
    }

    @UtilityClass
    public class RescueServiceConstants {

        public static final String ALL = "ALL";
        public static final String DATE_FORMAT = "yyyy-MM-dd";
    }

}
