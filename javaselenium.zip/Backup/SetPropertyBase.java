package com.equifax.ews.I9RescueServiceUtilities;

import com.equifax.ews.env.PropertyConfigurationReader;

import java.util.Properties;

public class SetPropertyBase {


    public static String CURRENTPATH  = System.getProperty("user.dir");
    public static String OUTPUT_ZIP_FILE_PATH;
    public static String  ARCHIVE_ZIP_FILE_PATH;
    public static String  ERROR_ZIP_FILE_PATH;
    public static String OUTPUT_ZIP_FILE;
    public static String  EMPLOYER_NAME;
    public static String EMPLOYEE_NAME;
    public static String I9_VERSION;
    public static String EMPLOYER_IDENTIFIER;
    public static String EMPLOYER_IDENTIFIER_CONVERTER;
    public static String EMPLOYER_IDENTIFIER_ACTUAL;

    public static String INVALID_FOLDER_PATH = null;
    public static String SOURCE_FOLDER;
    public static String ARCHIVE_ERROR_FOLDER;
    //public static String JSON_TEMPLATE_FOLDER;
    public static String JSON_FIELD_MAP_FILE_NAME;
    public static String TESTSUMMARYFOLDER;
    public static String TESTRESOURCEFOLDER;
    public static String JSON_COPY;

    public static String EMPLOYEE_TEMPLATE_PAYROLL_FILEPATH ;
    public static String EMPLOYEE_TEMPLATE_IMAGE_FILEPATH;
    public static String EMPLOYEE_TEMPLATE_IMAGE_FILEPATH_HIGHRESOLUTION;
    public static String EMPLOYEE_TEMPLATE_SUPPORTING_IMAGE_FILEPATH;
    public static String EMPLOYEE_TEMPLATE_PDF_FILEPATH ;
    //public static String TESTBATCH;
    public static String NEW_TEST_BATCH_NAME;


    public static String EMPLOYEE_PDF_FILEPATH ;
    public  static String EMPLOYEE_PAYROLL_FILEPATH ;
    public static String EMPLOYEE_IMAGE_FILEPATH ;
    public static String EMPLOYEE_SUPPORTING_IMAGE_FILEPATH ;
    public static String BUCKET_NAME;
    public static String SUBSCRIPTION_NAME;
    private static Properties prop;

    public static String IMAGE_FILENAME_TO_ZIP;
    public static String PAYROLL_FILENAME_TO_ZIP;
    public static String SUPPORTING_IMAGE_FILENAME_TO_ZIP;
    public static String PDF_FILENAME_TO_ZIP;
    public static int FIRESTORE_WAIT_COUNT;
    public static int FIRESTORE_WAIT_TIME;

    public static String EMPLOYEE_INVALID_FILEPATH ;
    public static String EMPLOYEE_TEMPLATE_JPG_FILEPATH;
    public static String SEARCH_FILENAME;

    public static String GCP_INGESTION_BUCKET   ;
    public static String GCP_INGESTION_ERROR_BUCKET ;
    public static String GCP_INGESTION_REJECTION_BUCKET ;
    public static String GCP_INGESTION_TEMP_BUCKET ;
    public static String GCP_INGESTION_IMAGE_BUCKET ;
    public static String GCP_INGESTION_PAYROLL_BUCKET ;
    public static String GCP_INGESTION_I9_BUCKET ;

    public static String GCP_FIRESTORE_INGESTION_COLLECTIONNAME ;
    public static String GCP_FIRESTORE_CONVERTER_COLLECTIONNAME ;
    public static String GCP_FIRESTORE_RESCUE_COLLECTIONNAME;
    public static String GCP_FIRESTORE_AUDITOR_COLLECTIONNAME;
    public static String GCP_FIRESTORE_GRAPH_YEAR_COLLECTIONNAME;
    public static String GCP_FIRESTORE_GRAPH_MONTH_COLLECTIONNAME;
    public static String GCP_FIRESTORE_GRAPH_WEEK_COLLECTIONNAME;

    public static String GOOGLE_KEY_RESOURCE_ID;
    public static String KEYSTORE_COLLECTION;
    public static String i9_TEMPLATE_FILE_NAME;
    public static String CRYPTO_ENABLED;

    public static String TIME_FORMAT;

    public static String publicKey;
    public static String processingFolder;
    public static String passphrase;
    public static String MD5hashValue;
    public static String OUTPUT_ZIP_FILE_PATH_ENCRYPTED;
    public static String MAX_FINE_PER_FORM;
    public static String AUDITRESULTFILE =null;
    public static String BATCH_IDENTIFIER;

    public static String VAULT_ADDR;
    public static String VAULT_NAMESPACE;
    public static String VAULT_TOKEN;
    public static String VAULT_SECRETKEYPATH;
    public static String VAULT_USERNAMEKEY;
    public static String VAULT_PASSWORDKEY;
    public static String VAULT_CONVERT_USERNAMEKEY;
    public static String VAULT_CONVERT_PASSWORDKEY;
    public static String VAULT_USERCODE;
    public static String VAULT_SUSER;
    public static String VAULT_SPIN;

    public static String TEST_CASE_ID;

    public static String SPANNER_DB_INSTANCE;
    public static String SPANNER_DATABASE;
    public static String PROJECT_ID_SPANNER;

    public static String PROJECT_ID;
    public static String I9_IDENTIFIER;



    public static void assignPropValues() {


        prop = PropertyConfigurationReader.ConfigurationReader();
        SOURCE_FOLDER= CURRENTPATH + prop.getProperty("INGESTIONFOLDER").toString();
        //ARCHIVE_ERROR_FOLDER = CURRENTPATH + prop.getProperty("ARCHIVE_ERROR_FOLDER").toString();
        TESTSUMMARYFOLDER = CURRENTPATH + prop.getProperty("TESTSUMMARYFOLDER").toString();
        TESTRESOURCEFOLDER = CURRENTPATH + prop.getProperty("TESTRESOURCEFOLDER").toString();
//        TESTBATCH = CURRENTPATH + prop.getProperty("TESTBATCH").toString();
        MAX_FINE_PER_FORM = prop.getProperty("MAX_FINE_PER_FORM").toString();
        JSON_COPY = CURRENTPATH + prop.getProperty("JSON_COPY").toString();

        //JSON_TEMPLATE_FOLDER= CURRENTPATH + prop.getProperty("JSON_TEMPLATE").toString();
        //JSON_FIELD_MAP_FILE_NAME= CURRENTPATH + prop.getProperty("JSON_FIELD_MAP_ARRAY").toString();
        EMPLOYEE_TEMPLATE_PAYROLL_FILEPATH= CURRENTPATH + prop.getProperty("EMPLOYEE_TEMPLATE_PAYROLL_FILEPATH").toString();
        EMPLOYER_IDENTIFIER = prop.getProperty("EMPLOYER_IDENTIFIER");
        EMPLOYER_IDENTIFIER_CONVERTER = prop.getProperty("EMPLOYER_IDENTIFIER_CONVERTER");

        EMPLOYER_IDENTIFIER_ACTUAL = prop.getProperty("EMPLOYER_IDENTIFIER_ACTUAL");
        EMPLOYEE_TEMPLATE_IMAGE_FILEPATH= CURRENTPATH + prop.getProperty("EMPLOYEE_TEMPLATE_IMAGE_FILEPATH").toString();
        EMPLOYEE_TEMPLATE_IMAGE_FILEPATH_HIGHRESOLUTION= CURRENTPATH + prop.getProperty("EMPLOYEE_TEMPLATE_IMAGE_FILEPATH_HIGHRESOLUTION").toString();
        EMPLOYEE_TEMPLATE_SUPPORTING_IMAGE_FILEPATH= CURRENTPATH + prop.getProperty("EMPLOYEE_TEMPLATE_SUPPORTING_IMAGE_FILEPATH").toString();
        EMPLOYEE_TEMPLATE_PDF_FILEPATH =  CURRENTPATH + prop.getProperty("EMPLOYEE_TEMPLATE_PDF_FILEPATH").toString();
        BUCKET_NAME= prop.getProperty("BUCKET_NAME").toString();
        SUBSCRIPTION_NAME= prop.getProperty("SUBSCRIPTION_NAME").toString();
        EMPLOYEE_TEMPLATE_JPG_FILEPATH =  CURRENTPATH + prop.getProperty("EMPLOYEE_TEMPLATE_JPG_FILEPATH").toString();

        IMAGE_FILENAME_TO_ZIP = prop.getProperty("IMAGE_FILENAME_TO_ZIP").toString();
        PAYROLL_FILENAME_TO_ZIP= prop.getProperty("PAYROLL_FILENAME_TO_ZIP").toString();
        SUPPORTING_IMAGE_FILENAME_TO_ZIP= prop.getProperty("SUPPORTING_IMAGE_FILENAME_TO_ZIP").toString();
        PDF_FILENAME_TO_ZIP= prop.getProperty("PDF_FILENAME_TO_ZIP").toString();
        FIRESTORE_WAIT_COUNT= Integer.parseInt(prop.getProperty("FIRESTORE_WAIT_COUNT"));
        FIRESTORE_WAIT_TIME= Integer.parseInt(prop.getProperty("FIRESTORE_WAIT_TIME"));

        //This is for GCP bucket configurations
        GCP_INGESTION_BUCKET = prop.getProperty("GCP_INGESTION_BUCKET").toString();
        GCP_INGESTION_ERROR_BUCKET = prop.getProperty("GCP_INGESTION_ERROR_BUCKET").toString();
        GCP_INGESTION_REJECTION_BUCKET = prop.getProperty("GCP_INGESTION_REJECTION_BUCKET").toString();
        //GCP_INGESTION_TEMP_BUCKET= prop.getProperty("GCP_INGESTION_TEMP_BUCKET").toString();
        GCP_INGESTION_IMAGE_BUCKET = prop.getProperty("GCP_INGESTION_IMAGE_BUCKET").toString();
        GCP_INGESTION_PAYROLL_BUCKET = prop.getProperty("GCP_INGESTION_PAYROLL_BUCKET").toString();
        GCP_INGESTION_I9_BUCKET = prop.getProperty("GCP_INGESTION_I9_BUCKET").toString();

        GCP_FIRESTORE_INGESTION_COLLECTIONNAME = prop.getProperty("GCP_FIRESTORE_INGESTION_COLLECTIONNAME").toString();
        GCP_FIRESTORE_CONVERTER_COLLECTIONNAME = prop.getProperty("GCP_FIRESTORE_CONVERTER_COLLECTIONNAME").toString();
        GCP_FIRESTORE_RESCUE_COLLECTIONNAME =  prop.getProperty("GCP_FIRESTORE_RESCUE_COLLECTIONNAME").toString();
        GCP_FIRESTORE_AUDITOR_COLLECTIONNAME=  prop.getProperty("GCP_FIRESTORE_AUDITOR_COLLECTIONNAME").toString();
        GCP_FIRESTORE_GRAPH_YEAR_COLLECTIONNAME= prop.getProperty("GCP_FIRESTORE_GRAPH_YEAR_COLLECTIONNAME");
        GCP_FIRESTORE_GRAPH_MONTH_COLLECTIONNAME= prop.getProperty("GCP_FIRESTORE_GRAPH_MONTH_COLLECTIONNAME");
        GCP_FIRESTORE_GRAPH_WEEK_COLLECTIONNAME= prop.getProperty("GCP_FIRESTORE_GRAPH_WEEK_COLLECTIONNAME");

        GOOGLE_KEY_RESOURCE_ID = prop.getProperty("GOOGLE_KEY_RESOURCE_ID").toString();
        KEYSTORE_COLLECTION = prop.getProperty("KEYSTORE_COLLECTION").toString();
        i9_TEMPLATE_FILE_NAME = prop.getProperty("i9_TEMPLATE_FILE_NAME").toString();
        CRYPTO_ENABLED = prop.getProperty("CRYPTO_ENABLED").toString();

        publicKey = prop.getProperty("publicKey").toString();

//        VAULT_ADDR = prop.getProperty("VAULT_ADDR").toString();
//        VAULT_NAMESPACE= prop.getProperty("VAULT_NAMESPACE").toString();
//        VAULT_TOKEN= prop.getProperty("VAULT_TOKEN").toString();
//        VAULT_SECRETKEYPATH= prop.getProperty("VAULT_SECRETKEYPATH").toString();
//        VAULT_USERNAMEKEY= prop.getProperty("VAULT_USERNAMEKEY").toString();
//        VAULT_PASSWORDKEY= prop.getProperty("VAULT_PASSWORDKEY").toString();
//        VAULT_CONVERT_USERNAMEKEY= prop.getProperty("VAULT_CONVERT_USERNAMEKEY").toString();
//        VAULT_CONVERT_PASSWORDKEY= prop.getProperty("VAULT_CONVERT_PASSWORDKEY").toString();
//        VAULT_USERCODE= prop.getProperty("VAULT_USERCODE").toString();
//        VAULT_SUSER= prop.getProperty("VAULT_SUSER").toString();
//        VAULT_SPIN= prop.getProperty("VAULT_SPIN").toString();

        PROJECT_ID= prop.get("PROJECT_ID").toString();
        PROJECT_ID_SPANNER= prop.getProperty("PROJECT_ID_SPANNER").toString();
        SPANNER_DB_INSTANCE = prop.getProperty("SPANNER_DB_INSTANCE").toString();
        SPANNER_DATABASE = prop.getProperty("SPANNER_DATABASE").toString();

    }
}
