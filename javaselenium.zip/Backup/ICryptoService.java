package com.equifax.ews.I9RescueServiceUtilities;

import org.bouncycastle.openpgp.PGPPublicKey;

import java.io.FileNotFoundException;


public interface ICryptoService {

    PGPPublicKey readPublicKey() throws FileNotFoundException;
    Boolean encryptFile(String inputFileName,String outPutFileName);

}
