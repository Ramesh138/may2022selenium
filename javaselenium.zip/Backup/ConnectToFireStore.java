package com.equifax.ews.I9RescueServiceUtilities;

import com.equifax.ews.I9RescueServiceUtilities.I9ConsolidatorRescueCollectionConstants.SearchableField;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.FieldPath;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.FirestoreOptions;
import com.google.cloud.firestore.Query;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONObject;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class ConnectToFireStore extends SetPropertyBase {

    List<QueryDocumentSnapshot> querySnapshotDocuments;
    List<QueryDocumentSnapshot> sortedDocuments;
    private static final String ALL = "ALL";
    Firestore dataBase;

    public ConnectToFireStore() {
        dataBase = FirestoreOptions.newBuilder().setProjectId(PROJECT_ID).build().getService();
    }

    public List<QueryDocumentSnapshot> checkRecordExistenceInFireStoreCollection(String CollectionName,
        String SearchFieldId_1, String SearchFieldVal_1, String SearchFieldId_2, String SearchFieldVal_2) {
        querySnapshotDocuments = null;
        try {
            querySnapshotDocuments = dataBase.collection(CollectionName).whereEqualTo(SearchFieldId_1, SearchFieldVal_1)
                .whereEqualTo(SearchFieldId_2, SearchFieldVal_2).get().get().getDocuments();
        } catch (InterruptedException | ExecutionException e) {
            log.error("ExecutionException or InterruptedException with fire store");
            e.printStackTrace();
        }
        return querySnapshotDocuments;
    }

    public JSONObject getDataFromFireStore(List<QueryDocumentSnapshot> querySnapshotDocuments) {
        sortedDocuments = null;
        sortedDocuments = querySnapshotDocuments.stream()
            .sorted(Comparator.comparing(DocumentSnapshot::getUpdateTime).reversed()).collect((Collectors.toList()));
        return getJsonFromMap(sortedDocuments.get(0).getData());
    }

    public Map<String, Object> getMapDataFromFireStore(List<QueryDocumentSnapshot> querySnapshotDocuments) {
        sortedDocuments = null;
        sortedDocuments = querySnapshotDocuments.stream()
            .sorted(Comparator.comparing(DocumentSnapshot::getUpdateTime).reversed()).collect((Collectors.toList()));
        return sortedDocuments.get(0).getData();
    }

    private JSONObject getJsonFromMap(Map<String, Object> map) {
        JSONObject jsonData = new JSONObject();
        for (String key : map.keySet()) {
            Object value = map.get(key);
            if (value instanceof Map<?, ?>) {
                value = getJsonFromMap((Map<String, Object>) value);
            }
            if (value == null) {
                jsonData.put(key, "");
            } else {
                jsonData.put(key, value);
            }
        }
        return jsonData;
    }

    public List<String> setParametersForFireStoreDocumentRetrieval(String Collection_Name) {

        List<String> parameters = new ArrayList<>();
        String QueryValue_2;
        String QueryKeyValue_2 = null;
        String QueryValue_1 = EMPLOYER_NAME + "_" + TIME_FORMAT;
        if (Collection_Name.equalsIgnoreCase("Ingestion")) {

            SEARCH_FILENAME = OUTPUT_ZIP_FILE;

            QueryKeyValue_2 = "zipFileName";
        } else if ((Collection_Name.equalsIgnoreCase("Converter")) || (Collection_Name.equalsIgnoreCase("Auditor"))) {

            SEARCH_FILENAME = MD5hashValue;

            QueryKeyValue_2 = "i9Identifier";
        }
        QueryValue_2 = SEARCH_FILENAME;
        parameters.add(0, "batchIdentifier");
        parameters.add(1, QueryValue_1);
        parameters.add(2, QueryKeyValue_2);
        parameters.add(3, QueryValue_2);
        return parameters;
    }

    public List<QueryDocumentSnapshot> retrieveFireStoreDocuments(String Collection_Name, List<String> parameters) {
        List<QueryDocumentSnapshot> querySnapshotDocuments = null;
        String CollectionName = null;
        if (Collection_Name.equalsIgnoreCase("Ingestion")) {
            CollectionName = GCP_FIRESTORE_INGESTION_COLLECTIONNAME;
        } else if (Collection_Name.equalsIgnoreCase("Converter")) {
            CollectionName = GCP_FIRESTORE_CONVERTER_COLLECTIONNAME;
        } else if (Collection_Name.equalsIgnoreCase("Rescue")) {
            ;
            CollectionName = GCP_FIRESTORE_RESCUE_COLLECTIONNAME;
        } else if (Collection_Name.equalsIgnoreCase("Auditor")) {
            CollectionName = GCP_FIRESTORE_AUDITOR_COLLECTIONNAME;
        }
        for (int retryCount = 1; retryCount <= FIRESTORE_WAIT_COUNT; retryCount++) {
            try {
                querySnapshotDocuments =
                    checkRecordExistenceInFireStoreCollection(CollectionName, parameters.get(0), parameters.get(1),
                        parameters.get(2),
                        parameters.get(3));
                if (querySnapshotDocuments.size() != 0) {
                    break;
                } else {
                    TimeUnit.SECONDS.sleep(FIRESTORE_WAIT_TIME);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return querySnapshotDocuments;
    }

    public String filterFireStoreResult(String searchKey, List<QueryDocumentSnapshot> querySnapshotDocumentList) {
        boolean testResult = false;
        String ActualOutPut = null;
        if (querySnapshotDocumentList != null && querySnapshotDocumentList.size() == 1) {
            if (searchKey.equalsIgnoreCase("auditResults") || searchKey.equalsIgnoreCase("preValidationErrors")
                || searchKey.equalsIgnoreCase("status") || searchKey.equalsIgnoreCase("rejectedFiles") || searchKey
                .equalsIgnoreCase("zipFileErrors") || searchKey.equalsIgnoreCase("i9Identifier")) {
                ActualOutPut = getDataFromFireStore(querySnapshotDocumentList).getAsString(searchKey);
            } else if (searchKey.equalsIgnoreCase("paperFormI9")) {
                ActualOutPut = getDataFromFireStore(querySnapshotDocumentList).getAsString(searchKey);
            } else if (searchKey.equalsIgnoreCase("i9Documents")) {
                ActualOutPut = getDataFromFireStore(querySnapshotDocumentList).getAsString("i9Documents");
                if (ActualOutPut != null && ActualOutPut.contains("formI9ImageName") && ActualOutPut
                    .contains("i9ImagePdf")) {
                    testResult = true;
                }
                if (testResult) {
                    ActualOutPut = "true";
                } else {
                    ActualOutPut = "false";
                }
            }
        } else {
            log.error("There is no or multiple document found for the search");
            ActualOutPut = "There is no or multiple document found for the search";
        }
        return ActualOutPut;
    }

    public Map<String, Object> filterMapObjectFromFireStoreResult(String searchKey,
        List<QueryDocumentSnapshot> querySnapshotDocumentList) {

        Map<String, Object> ActualOutPut = null;
        if (querySnapshotDocumentList != null && querySnapshotDocumentList.size() == 1) {
            if (searchKey.equalsIgnoreCase("auditResults")) {
                ActualOutPut = getMapDataFromFireStore(querySnapshotDocumentList);
            } else if (searchKey.equalsIgnoreCase("paperFormI9")) {
                ActualOutPut = getMapDataFromFireStore(querySnapshotDocumentList);
            }
        } else {
            log.error("There is no or multiple document found for the search");
        }
        return ActualOutPut;
    }

    /*

        public boolean ValidateAuditResult(String auditResultFile,Map<String, Object>  Result, DataTable errorList, String testCase){
            boolean testResult = true;
            String errorMessageContent = "";
            String sectionName = "";
            BufferedWriter auditResultWrite = null;
            List<DataTableRow> dataTableRows = errorList.getGherkinRows();
            int tableRows = dataTableRows.size();
            String[] arrOfExpectedErrMessages = new String [tableRows];
            String[] arrOfKeyFields = new String [tableRows];
            try{
                auditResultWrite = new BufferedWriter( new FileWriter(auditResultFile) );

                if (Result != null) {

                    auditResultWrite.write("Audit Test case" +":" + testCase );
                    auditResultWrite.newLine();
                    auditResultWrite.write("----------------------------------");
                    auditResultWrite.newLine();

                    for (int itr = 0; itr < tableRows; itr++) {
                        arrOfKeyFields[itr] = dataTableRows.get(itr).getCells().get(0);
                        arrOfExpectedErrMessages[itr] = dataTableRows.get(itr).getCells().get(1);
                        sectionName = arrOfKeyFields[itr].split("\\.")[0];
                        Optional<String> errorMessage= getErrorMessageByFieldName(Result,"/auditResults/"+sectionName,arrOfKeyFields[itr]);

                        if(errorMessage.isPresent()) {
                            errorMessageContent = errorMessage.get();
                            if (errorMessageContent.equalsIgnoreCase(arrOfExpectedErrMessages[itr])) {

                                auditResultWrite.write( arrOfKeyFields[itr] + ":" + " Pass");
                                auditResultWrite.newLine();
                                log.info("The expected error message '" + arrOfExpectedErrMessages[itr]+"' is found in the collection");
                            }else{
                                testResult = false;
                                auditResultWrite.write( arrOfKeyFields[itr] + ":" + " Fail  " + "Actual " + ":" +errorMessageContent + " Expected " + ":" + arrOfExpectedErrMessages[itr]);
                                auditResultWrite.newLine();
                                log.info("The expected error message  '" + arrOfExpectedErrMessages[itr]+"' is not found in the collection");
                            }
                        }
                        else if(!errorMessage.isPresent() && arrOfExpectedErrMessages[itr].isBlank()){
                            auditResultWrite.write( arrOfKeyFields[itr] + ":" + " Pass");
                            auditResultWrite.newLine();
                            log.info("The field '" + arrOfKeyFields[itr]+"' does not have any error message as expected");
                        }


                        else {
                            testResult = false;
                            auditResultWrite.write( arrOfKeyFields[itr] + ":" + " Fail " + "Actual " + ":" +errorMessageContent + " Expected " + ":" + arrOfExpectedErrMessages[itr]);
                            auditResultWrite.newLine();
                            log.info("There is no error message found for " + arrOfKeyFields[itr]);
                        }
                    }
                    auditResultWrite.flush();
                }else{
                    testResult = false;
                    log.info("Document is not uniquely identified after search");
                }
            }catch(IOException e){
                testResult = false;
                e.printStackTrace();
            }finally{
                try{
                    auditResultWrite.close();
                }catch(Exception e){}
            }
            return testResult;
        }

    */
    public static JsonNode getI9FormFieldValueV2(Map<String, Object> jsonData, String fieldName) {

        ObjectMapper mapper = new ObjectMapper();
        JsonNode actualObj = null;
        actualObj = mapper.convertValue(jsonData, JsonNode.class);

        return actualObj.at(fieldName);
    }

    public static <T> T generateObject(String payloadJson, Class<T> type) {
        ObjectMapper mapper = new ObjectMapper();
        T objectPayload = null;
        try {
            objectPayload = mapper.readValue(payloadJson, type);
        } catch (JsonProcessingException e) {

        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        return objectPayload;
    }

    public static Optional<String> getErrorMessageByFieldName(Map<String, Object> jsonData, String section,
        String fieldName) {
        try {
            List<Error> errorList = Arrays
                .asList(generateObject(getI9FormFieldValueV2(jsonData, section).toString(),
                    Error[].class));
            return errorList.stream().filter(field -> field.getFieldName().equals(fieldName))
                .map(field -> field.getErrorMessage()).findFirst();
        } catch (NullPointerException e) {
            //TODO LOG
        }
        return Optional.empty();
    }

    /**
     * get Overview Count with employerId, locationId, status and BatchIdentifier
     *
     * @param collectionName
     * @param employerId
     * @param locationId
     * @param status
     * @param batchIdentifier
     * @return
     */
    public int getOverviewCount(String collectionName, String employerId, String locationId, String status,
        String batchIdentifier) {
        int count = 0;
        try {
            Query query = dataBase.collection(collectionName)
                .whereEqualTo(FieldPath.of(I9ConsolidatorRescueCollectionConstants.SearchableField.EMPLOYER_ID),
                    employerId);
            if (!ALL.equalsIgnoreCase(locationId)) {
                query = query
                    .whereEqualTo(FieldPath.of(I9ConsolidatorRescueCollectionConstants.SearchableField.LOCATION_ID),
                        locationId);
            }
            if (StringUtils.isNotBlank(status)) {
                query = query
                    .whereEqualTo(FieldPath.of(I9ConsolidatorRescueCollectionConstants.SearchableField.STATUS), status);
            }
            if (StringUtils.isNotBlank(batchIdentifier)) {
                query = query.whereEqualTo(
                    FieldPath.of(I9ConsolidatorRescueCollectionConstants.SearchableField.BATCH_IDENTIFIER),
                    batchIdentifier);
            }
            count = query.get().get().size();
        } catch (Exception e) {
            log.error("ExecutionException or InterruptedException with fire store");
        }
        return count;
    }

    /**
     * Get data within a range of date
     * @param collection
     * @param employerId
     * @param locationId
     * @param fieldName
     * @param startLimitValue
     * @param endLimitValue
     * @return
     */
    public Optional<List<AuditGraphResult>> getAuditDataWithinRange(String collection, String employerId,
        String locationId, String fieldName, Object startLimitValue, Object endLimitValue) {
        Optional<List<AuditGraphResult>> auditGraphResultList = null;
        try {
            Query query = dataBase.collection(collection)
                .whereEqualTo(FieldPath.of(SearchableField.EMPLOYER_ID), employerId);
            if (!ALL.equalsIgnoreCase(locationId)) {
                query = query.whereEqualTo(FieldPath.of(SearchableField.LOCATION_ID), locationId);
            }
            query = query.whereGreaterThanOrEqualTo(fieldName, startLimitValue)
                .whereLessThanOrEqualTo(fieldName, endLimitValue);
            auditGraphResultList = Optional.ofNullable(query.get().get().toObjects(AuditGraphResult.class));
        } catch (InterruptedException e) {
            log.error("ExecutionException or InterruptedException with fire store");
        } catch (Exception e) {
            log.error("ExecutionException or InterruptedException with fire store");
        }
        return auditGraphResultList;
    }
}
