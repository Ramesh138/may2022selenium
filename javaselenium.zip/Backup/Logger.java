package com.equifax.ews.logging;

/**
 * Logger interface.
 */
public interface Logger {

    /**
     * Logger to log info messages.
     *
     * @param message - Info message
     */
    void info(String message);

    /**
     * Logger to log info messages and Throwable.
     *
     * @param message - Info message
     * @param t       - Throwable String
     */
    void info(String message, Throwable t);

    /**
     * Logger to log debug messages.
     *
     * @param message - Info message
     */
    void debug(String message);

    /**
     * Logger to log debug messages and Throwable.
     *
     * @param message - Info message
     * @param t       - Throwable String
     */
    void debug(String message, Throwable t);

    /**
     * Logger to log error messages.
     *
     * @param message - Info message
     */
    void error(String message);

    /**
     * Logger to log error messages and Throwable.
     *
     * @param message - Info message
     * @param t       - Throwable String
     */
    void error(String message, Throwable t);

    /**
     * Logger to log fatal messages.
     *
     * @param message - Info message
     */
    void fatal(String message);

    /**
     * Logger to log debug messages and Throwable.
     *
     * @param message - Info message
     * @param t       - Throwable String
     */
    void fatal(String message, Throwable t);

    /**
     * Logger to log warn messages.
     *
     * @param message - Info message
     */
    void warn(String message);

    /**
     * Logger to log debug messages and Throwable.
     *
     * @param message - Info message
     * @param t       - Throwable String
     */
    void warn(String message, Throwable t);

    /**
     * Gets th name.
     *
     * @return - String
     */
    String getName();

    /**
     * Prints the stack trace to log.
     *
     * @param t - Throwable object.
     */
    void printStackTrace(Throwable t);
}
