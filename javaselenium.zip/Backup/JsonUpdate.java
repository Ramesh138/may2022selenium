package com.equifax.ews.I9RescueServiceUtilities;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.HashMap;

public class JsonUpdate extends SetPropertyBase{

    public static void updateJson(String inputPath, String outputPath, HashMap<String, Object> value) {
        ObjectMapper mapper = new ObjectMapper();
        JSONParser parser = new JSONParser();
        try {
            Object obj = parser.parse(new FileReader(String.valueOf(Paths.get(inputPath))));
            JSONObject jsonObject = (JSONObject) obj;
            value.forEach((k, v) -> {
                DocumentContext doc = JsonPath.parse(jsonObject);
                doc.set(k, v);
            });
            FileWriter file = new FileWriter(String.valueOf(Paths.get(outputPath)));
            file.write(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject));
            file.close();
        } catch (ParseException | IOException e) {
            e.printStackTrace();
        }

    }
}
