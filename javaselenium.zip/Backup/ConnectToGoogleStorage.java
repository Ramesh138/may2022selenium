package com.equifax.ews.I9RescueServiceUtilities;

import com.google.cloud.storage.*;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

@Slf4j
public class ConnectToGoogleStorage extends SetPropertyBase{
    Storage storage;
    public ConnectToGoogleStorage() {
        storage = StorageOptions.newBuilder().setProjectId(PROJECT_ID).build().getService();
    }

    public void moveFilesToStorage(String OUTPUT_ZIP_FILE_PATH, String fileName,String BUCKET_NAME){
        try {
            BlobInfo blobInfo = BlobInfo.newBuilder(BUCKET_NAME, fileName)
                    .setContentType("application/octet-stream")
                    .setContentDisposition(String.format("attachment; filename=\"%s\"", fileName)).build();
            storage.create(blobInfo, Files.readAllBytes(Paths.get(OUTPUT_ZIP_FILE_PATH)));
        }
        catch (Exception exception) {
            log.error(" Exception in moving files to storage");
        }
    }

    public boolean getBlob(String bucketName, String blobName) {
        boolean result = false;
        BlobId blobId = BlobId.of(bucketName, blobName);
        Blob test = storage.get(blobId);
        if (test != null) {
            result = true;
        }
        return result;
    }


    public String formatStorageNameForFileSearch(String StorageName) {
        String actStorageName = "";
        if (StorageName.equalsIgnoreCase("errorstorage")) {
            actStorageName = GCP_INGESTION_ERROR_BUCKET;
        } else if (StorageName.equalsIgnoreCase("ingestionstorage")) {
            actStorageName = GCP_INGESTION_BUCKET;
        } else if (StorageName.equalsIgnoreCase("imagestorage")) {
            actStorageName = GCP_INGESTION_IMAGE_BUCKET;
        } else if (StorageName.equalsIgnoreCase("payrollstorage")) {
            actStorageName = GCP_INGESTION_PAYROLL_BUCKET;
        } else if (StorageName.equalsIgnoreCase("jsonstorage")) {
            actStorageName = GCP_INGESTION_I9_BUCKET;
        }
        else if (StorageName.equalsIgnoreCase("rejectionstorage")) {
            actStorageName = GCP_INGESTION_REJECTION_BUCKET;
        }
        return actStorageName;
    }

    public String formatFileNameForFileSearchInStorage(String FileName) {
        String actFileName = "";
        String folderName = EMPLOYER_NAME + "_" + TIME_FORMAT;
        if (FileName.equalsIgnoreCase("zip")) {
            actFileName = folderName + "/" + OUTPUT_ZIP_FILE;
        } else {
            actFileName = folderName + "/" + FileName;
        }
        return actFileName;
    }

    public boolean checkFilesInStorage(String StorageName, String FileName) throws Throwable {

        String actStorageName , actFileName = "";
        Boolean testResult = false;
        ConnectToGoogleStorage objSearchStorage = new ConnectToGoogleStorage();
        try {
            actStorageName = objSearchStorage.formatStorageNameForFileSearch(StorageName);
            if (StorageName.equalsIgnoreCase("ingestionstorage")|| StorageName.equalsIgnoreCase("rejectionstorage")) {
                if (FileName.equalsIgnoreCase("zip")) {
                    actFileName = OUTPUT_ZIP_FILE;
                } else {
                    actFileName = FileName;
                }
            }else {
                actFileName = objSearchStorage.formatFileNameForFileSearchInStorage(FileName);
            }
            if (!actStorageName.isEmpty()) {
                if (!actFileName.isEmpty()) {

                    for(int retryCount = 1 ; retryCount<=FIRESTORE_WAIT_COUNT; retryCount++)
                    {
                        try {
                            ConnectToGoogleStorage cloudUpload = new ConnectToGoogleStorage();
                            testResult = cloudUpload.getBlob(actStorageName, actFileName);
                            if(testResult) {
                                break;
                            }else {
                                TimeUnit.SECONDS.sleep(FIRESTORE_WAIT_TIME);
                            }
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    //Assert.assertTrue(testResult);
                } else {
                    log.error("File name " +FileName + " is not provided to search the file");
                }
            } else {
                log.error("Storage " + StorageName + " is not valid to search the file");
            }
        }catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in searching file in storage");
        }

        return testResult;
    }

}