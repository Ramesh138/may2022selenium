package com.equifax.ews.I9RescueServiceUtilities;

import lombok.extern.slf4j.Slf4j;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


/*
    This utility is used for folder creation, copy necessary files to the desired location, moving the zip files to archive-error location etc
 */
@Slf4j
public class FolderFileManagement extends SetPropertyBase {

    boolean folderResult;

    public String createFolder( String parentFolderPath, String folderName) {
        String fileName = parentFolderPath + File.separator + folderName;
        if ((!parentFolderPath.isEmpty()) || (!folderName.isEmpty())) {
            File createfile = new File(parentFolderPath, folderName);
            log.info(" Trying to create the folder" + folderName);
            if (!createfile.exists()) {
                folderResult = createfile.mkdir();
                if (folderResult) {
                    log.info(folderName + "  :  created successfully");
                    if (folderName != "InputIngestionFolder" && folderName != "EncryptedZipToUpload" && folderName != "TestSummary") {
                        File testFile = new File(fileName, "test.txt");
                        try {
                            testFile.createNewFile();

                        } catch (IOException e) {
                            e.printStackTrace();
                            log.error("IOException while creating the file: test.txt ");
                        }
                    }
                }

            } else {
                log.info(folderName + " :  is already present:");
            }

        } else {
            log.info(" Names supplied to create the folder is empty");
        }
        return fileName;
    }

    public String createFileIfNotExist(String fileName) {
        createFolder( TESTRESOURCEFOLDER, "TestSummary");
        String fileNamePath= TESTSUMMARYFOLDER + File.separator + fileName;
        File file = new File(TESTSUMMARYFOLDER, fileName);
        if (!file.exists()) {
            try {
                file.createNewFile();
                log.info("File is created!");
            } catch (IOException e) {
                e.printStackTrace();
                log.error("IOException while creating the file ");
            }
        } else {
            log.info("File already existed!");
        }
        return fileNamePath;
    }


    public void archive_error_ZipFolder(String zipFolderPath, String archiveFolderPath)
    {
            Path temp = null;
            try {
                temp = Files.move(Paths.get(zipFolderPath),
                    Paths.get(archiveFolderPath));
            } catch (IOException e) {
                e.printStackTrace();
                log.error("IOException while moving the file to the destination location");
            }
            if (temp != null) {
                log.info("Zip Folder successfully moved to the destination location!");
            }
    }

    public void copyFile(String SourceFile, String DestinationFile){

        InputStream inStream;
        OutputStream outStream;
        try{
            File source =new File(SourceFile);
            File destination =new File(DestinationFile);
            inStream = new FileInputStream(source);
            outStream = new FileOutputStream(destination);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inStream.read(buffer)) > 0){
                outStream.write(buffer, 0, length);
            }
            inStream.close();
            outStream.close();
        }catch(IOException e){
            e.printStackTrace();
            log.error("IOException while copying the file" + SourceFile);
        }
    }


}




