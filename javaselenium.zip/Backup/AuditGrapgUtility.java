package com.equifax.ews.I9RescueServiceUtilities;

import com.equifax.ews.I9RescueServiceUtilities.I9ConsolidatorRescueCollectionConstants.RescueServiceConstants;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;


@Slf4j
public class AuditGrapgUtility {

    private static final int INTERVAL = 12;
    private static final String RANGE_QUERY_START_END_FROM = "Range query {} start {} end {} from {}";
    private static final String RESULT_FROM_THE_COLLECTION = "Result from the collection {}";
    private static final String GENERATING_THE_DTO = "Generating the DTO";
    private static final String NO_RESULT_FROM_THE_COLLECTION = "No result from the collection";
    ConnectToFireStore connectToFireStore = new ConnectToFireStore();

    /**
     * GET AUDIT GRAPH FOR YEAR
     *
     * @param employerId
     * @param locationId
     * @return
     */
    public List<AuditGraphResultDTO> getAuditGraphYearlyResult(String collection, String employerId, String locationId) {
        ZoneId defaultZoneId = ZoneId.of("UTC");;
        LocalDate localDate = LocalDate.now();
        int endYear = localDate.atStartOfDay(defaultZoneId).getYear();
        int startYear = localDate.minusYears(INTERVAL - 1).atStartOfDay(defaultZoneId).getYear();
        log.info(RANGE_QUERY_START_END_FROM, "year", startYear, endYear,
                collection);
        Optional<List<AuditGraphResult>> collectionData = connectToFireStore
                .getAuditDataWithinRange(collection, employerId, locationId,
                        "year", startYear, endYear);
        if (collectionData.isPresent() && CollectionUtils.isNotEmpty(collectionData.get())) {
            log.info(RESULT_FROM_THE_COLLECTION, collectionData.get().size());
            List<AuditGraphResult> aggregatedResult;
            if (RescueServiceConstants.ALL.equalsIgnoreCase(locationId)) {
                aggregatedResult = this.performAggregation(collectionData.get(), Frequency.year.name());
            } else {
                aggregatedResult = collectionData.get();
            }
            log.info(GENERATING_THE_DTO);
            return this.generateDTOAndFillEmptyYearlyObjects(aggregatedResult, startYear, locationId);
        }
        log.info(NO_RESULT_FROM_THE_COLLECTION);
        return this.generateWholeEmptyObjectsInCaseOfRecordsNotFound(employerId, locationId, startYear, null,
                Frequency.year.name());
    }

    /**
     * GET AUDIT GRAPH FOR MONTH
     *
     * @param employerId
     * @param locationId
     * @return
     */
    public List<AuditGraphResultDTO> getAuditGraphMonthlyResult(String collection, String employerId, String locationId) {
        ZoneId defaultZoneId = ZoneId.of("UTC");
        LocalDate localDate = LocalDate.now();
        Date endDate = Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());
        Date startDate = Date
                .from(localDate.minusMonths(INTERVAL - 1).atStartOfDay(defaultZoneId).withDayOfMonth(1).toInstant());
        log.info(RANGE_QUERY_START_END_FROM, "month", startDate, endDate,
                collection);
        Optional<List<AuditGraphResult>> collectionData = connectToFireStore
                .getAuditDataWithinRange(collection, employerId, locationId,
                        "month", startDate, endDate);
        if (collectionData.isPresent() && CollectionUtils.isNotEmpty(collectionData.get())) {
            log.info(RESULT_FROM_THE_COLLECTION, collectionData.get().size());
            List<AuditGraphResult> aggregatedResult;
            if (RescueServiceConstants.ALL.equalsIgnoreCase(locationId)) {
                aggregatedResult = this.performAggregation(collectionData.get(), Frequency.month.name());
            } else {
                aggregatedResult = collectionData.get();
            }
            log.info(GENERATING_THE_DTO);
            return this.generateDTOAndFillEmptyMonthlyObjects(aggregatedResult, startDate, locationId);
        }
        log.info(NO_RESULT_FROM_THE_COLLECTION);
        return this.generateWholeEmptyObjectsInCaseOfRecordsNotFound(employerId, locationId, 0, startDate,
                Frequency.month.name());
    }

    /**
     * GET AUDIT GRAPH FOR WEEK
     *
     * @param employerId
     * @param locationId
     * @return
     */
    public List<AuditGraphResultDTO> getAuditGraphWeeklyResult(String collection, String employerId, String locationId) {
        ZoneId defaultZoneId = ZoneId.of("UTC");
        LocalDate localDate = LocalDate.now(defaultZoneId);
        Date endDate = Date.from(localDate
                .with(TemporalAdjusters.previousOrSame(WeekFields.of(Locale.US).getFirstDayOfWeek()))
                .atStartOfDay(defaultZoneId).toInstant());
        Date startDate = Date.from(localDate
                .with(TemporalAdjusters.previousOrSame(WeekFields.of(Locale.US).getFirstDayOfWeek()))
                .minusWeeks(INTERVAL - 1)
                .atStartOfDay(defaultZoneId).toInstant());
        log.info(RANGE_QUERY_START_END_FROM, "week", startDate, endDate,
                collection);
        Optional<List<AuditGraphResult>> collectionData = connectToFireStore
                .getAuditDataWithinRange(collection, employerId, locationId,
                        "weekStart", startDate, endDate);
        if (collectionData.isPresent() && CollectionUtils.isNotEmpty(collectionData.get())) {
            log.info(RESULT_FROM_THE_COLLECTION, collectionData.get().size());
            List<AuditGraphResult> aggregatedResult;
            if (RescueServiceConstants.ALL.equalsIgnoreCase(locationId)) {
                aggregatedResult = this.performAggregation(collectionData.get(), Frequency.week.name());
            } else {
                aggregatedResult = collectionData.get();
            }
            log.info(GENERATING_THE_DTO);
            return this.generateDTOAndFillEmptyWeeklyObjects(aggregatedResult, startDate, locationId);
        }
        log.info(NO_RESULT_FROM_THE_COLLECTION);
        return this.generateWholeEmptyObjectsInCaseOfRecordsNotFound(employerId, locationId, 0, startDate,
                Frequency.week.name());
    }

    /**
     * @param resultData
     * @param startDate
     * @param locationId
     * @return
     */
    private List<AuditGraphResultDTO> generateDTOAndFillEmptyWeeklyObjects(List<AuditGraphResult> resultData,
                                                                           Date startDate, String locationId) {
        ZoneId defaultZoneId = ZoneId.of("UTC");
        log.info("Generating the weekly DTO");
        Map<Object, List<AuditGraphResult>> groupedMap = resultData.stream()
                .collect(Collectors.groupingBy(AuditGraphResult::getWeekStart));
        List<AuditGraphResultDTO> responseDTO = new ArrayList<>(INTERVAL);
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(RescueServiceConstants.DATE_FORMAT);
        for (int i = 1; i <= INTERVAL; i++) {
            AuditGraphResultDTO dataDto;
            if (groupedMap.containsKey(startDate)) {
                AuditGraphResult matchedRecord = groupedMap.get(startDate).get(0);
                dataDto = this.copyToDTOFromEntity(matchedRecord, locationId);
                dataDto.setWeekStart(dateFormatter
                        .format(matchedRecord.getWeekStart().toInstant().atZone(defaultZoneId).toLocalDate()));
            } else {
                dataDto = this.generateEmptyObject(resultData.get(0).getEmployerIdentifier(), locationId);
                dataDto.setWeekStart(
                        dateFormatter.format(startDate.toInstant().atZone(defaultZoneId).toLocalDate()));
            }
            responseDTO.add(dataDto);
            startDate = Date.from(startDate.toInstant().atZone(defaultZoneId).toLocalDate().plusWeeks(1)
                    .atStartOfDay(defaultZoneId).toInstant());
        }
        return responseDTO;
    }

    /**
     * @param resultData
     * @param startDate
     * @param locationId
     * @return
     */
    private List<AuditGraphResultDTO> generateDTOAndFillEmptyMonthlyObjects(List<AuditGraphResult> resultData,
                                                                            Date startDate, String locationId) {
        ZoneId defaultZoneId = ZoneId.of("UTC");
        log.info("Generating the monthly DTO");
        Map<Object, List<AuditGraphResult>> groupedMap = resultData.stream()
                .collect(Collectors.groupingBy(AuditGraphResult::getMonth));
        List<AuditGraphResultDTO> responseDTO = new ArrayList<>(INTERVAL);
        for (int i = 1; i <= INTERVAL; i++) {
            AuditGraphResultDTO dataDto;
            LocalDate recordDate;
            if (groupedMap.containsKey(startDate)) {
                AuditGraphResult matchedRecord = groupedMap.get(startDate).get(0);
                dataDto = this.copyToDTOFromEntity(matchedRecord, locationId);
                recordDate = matchedRecord.getMonth().toInstant().atZone(defaultZoneId).toLocalDate();
            } else {
                dataDto = this.generateEmptyObject(resultData.get(0).getEmployerIdentifier(), locationId);
                recordDate = startDate.toInstant().atZone(defaultZoneId).toLocalDate();
            }
            dataDto.setMonth(String.join(",", recordDate.getMonth().name(), String.valueOf(recordDate.getYear())));
            responseDTO.add(dataDto);
            startDate = Date.from(startDate.toInstant().atZone(defaultZoneId).toLocalDate().plusMonths(1)
                    .atStartOfDay(defaultZoneId).toInstant());
        }
        return responseDTO;
    }

    /**
     * @param resultData
     * @param startYear
     * @param locationId
     * @return
     */
    private List<AuditGraphResultDTO> generateDTOAndFillEmptyYearlyObjects(List<AuditGraphResult> resultData,
                                                                           int startYear, String locationId) {
        log.info("Generating the Yearly DTO");
        Map<Object, List<AuditGraphResult>> groupedMap = resultData.stream()
                .collect(Collectors.groupingBy(AuditGraphResult::getYear));
        List<AuditGraphResultDTO> responseDTO = new ArrayList<>(INTERVAL);
        for (int i = 1; i <= INTERVAL; i++) {
            AuditGraphResultDTO dataDto;
            if (groupedMap.containsKey(startYear)) {
                AuditGraphResult matchedRecord = groupedMap.get(startYear).get(0);
                dataDto = this.copyToDTOFromEntity(matchedRecord, locationId);
                dataDto.setYear(matchedRecord.getYear());
            } else {
                dataDto = this.generateEmptyObject(resultData.get(0).getEmployerIdentifier(), locationId);
                dataDto.setYear(startYear);
            }
            responseDTO.add(dataDto);
            startYear = startYear + 1;
        }
        return responseDTO;
    }

    /**
     * @param empId
     * @param locationId
     * @param startYear
     * @param startDate
     * @param frequency
     * @return
     */
    private List<AuditGraphResultDTO> generateWholeEmptyObjectsInCaseOfRecordsNotFound(String empId, String locationId,
                                                                                       int startYear, Date startDate, String frequency) {
        ZoneId defaultZoneId = ZoneId.systemDefault();
        log.info("Creating whole dummy data as records not found");
        List<AuditGraphResultDTO> responseDTO = new ArrayList<>();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(RescueServiceConstants.DATE_FORMAT);
        if (Frequency.year.name().equalsIgnoreCase(frequency)) {
            for (int i = 1; i <= INTERVAL; i++) {
                AuditGraphResultDTO dataDto = this.generateEmptyObject(empId, locationId);
                dataDto.setYear((Integer) startYear);
                responseDTO.add(dataDto);
                startYear = (Integer) startYear + 1;
            }
        }
        if (Frequency.month.name().equalsIgnoreCase(frequency)) {
            for (int i = 1; i <= INTERVAL; i++) {
                AuditGraphResultDTO dataDto = this.generateEmptyObject(empId, locationId);
                LocalDate recordDate = startDate.toInstant().atZone(defaultZoneId).toLocalDate();
                dataDto.setMonth(String.join(",", recordDate.getMonth().name(), String.valueOf(recordDate.getYear())));
                responseDTO.add(dataDto);
                startDate = Date.from(startDate.toInstant().atZone(defaultZoneId).toLocalDate().plusMonths(1)
                        .atStartOfDay(defaultZoneId).toInstant());
            }
        }

        if (Frequency.week.name().equalsIgnoreCase(frequency)) {
            for (int i = 1; i <= INTERVAL; i++) {
                AuditGraphResultDTO dataDto = this.generateEmptyObject(empId, locationId);
                dataDto.setWeekStart(
                        dateFormatter.format(startDate.toInstant().atZone(defaultZoneId).toLocalDate()));
                responseDTO.add(dataDto);
                startDate = Date.from(startDate.toInstant().atZone(defaultZoneId).toLocalDate().plusWeeks(1)
                        .atStartOfDay(defaultZoneId).toInstant());
            }
        }
        return responseDTO;
    }

    private List<AuditGraphResult> performAggregation(List<AuditGraphResult> collectionData, String groupBy) {
        log.info("Performing the aggregation of the data");
        Map<Object, List<AuditGraphResult>> groupedMap = null;
        if (Frequency.year.name().equalsIgnoreCase(groupBy)) {
            groupedMap = collectionData.stream().collect(Collectors.groupingBy(AuditGraphResult::getYear));
        } else if (Frequency.month.name().equalsIgnoreCase(groupBy)) {
            groupedMap = collectionData.stream().collect(Collectors.groupingBy(AuditGraphResult::getMonth));
        } else if (Frequency.week.name().equalsIgnoreCase(groupBy)) {
            groupedMap = collectionData.stream().collect(Collectors.groupingBy(AuditGraphResult::getWeekStart));
        } else {
            return new ArrayList();
        }
        log.info("Performed grouping on the data");
        Map<AuditGraphResult, List<AuditGraphResult>> aggregatedMap = groupedMap
                .entrySet().stream()
                .collect(Collectors.toMap(x -> {
                    int sumTotalI9sResolved = x.getValue().stream().mapToInt(AuditGraphResult::getTotalI9sResolved).sum();
                    int sumTotalNoOfIssues = x.getValue().stream().mapToInt(AuditGraphResult::getTotalNoOfIssues).sum();
                    int sumNoOfI9sWithIssues = x.getValue().stream().mapToInt(AuditGraphResult::getNoOfI9sWithIssues).sum();
                    int sumHistoricalI9sUploaded = x.getValue().stream()
                            .mapToInt(AuditGraphResult::getHistoricalI9sUploaded).sum();

                    AuditGraphResult aggregatedObj = new AuditGraphResult();
                    aggregatedObj.setEmployerIdentifier(x.getValue().get(0).getEmployerIdentifier());
                    aggregatedObj.setYear(x.getValue().get(0).getYear());
                    aggregatedObj.setMonth(x.getValue().get(0).getMonth());
                    aggregatedObj.setWeekStart(x.getValue().get(0).getWeekStart());
                    aggregatedObj.setHistoricalI9sUploaded(sumHistoricalI9sUploaded);
                    aggregatedObj.setNoOfI9sWithIssues(sumNoOfI9sWithIssues);
                    aggregatedObj.setTotalI9sResolved(sumTotalI9sResolved);
                    aggregatedObj.setTotalNoOfIssues(sumTotalNoOfIssues);

                    return aggregatedObj;
                }, Map.Entry::getValue));
        log.info("Performed aggregation of the data");
        return new ArrayList(aggregatedMap.keySet());
    }

    /**
     * @param resultData
     * @param locationId
     * @return
     */
    private AuditGraphResultDTO copyToDTOFromEntity(AuditGraphResult resultData, String locationId) {
        AuditGraphResultDTO dataDto = new AuditGraphResultDTO()
                .setEmployerIdentifier(resultData.getEmployerIdentifier())
                .setLocationIdentifier(locationId)
                .setHistoricalI9sUploaded(resultData.getHistoricalI9sUploaded())
                .setNoOfI9sWithIssues(resultData.getNoOfI9sWithIssues())
                .setTotalI9sResolved(resultData.getTotalI9sResolved())
                .setTotalNoOfIssues(resultData.getTotalNoOfIssues())
                .setPotentialFineRisk(
                        BigDecimal.valueOf(resultData.getNoOfI9sWithIssues() * 2332)
                                .setScale(1, RoundingMode.HALF_EVEN));
        return dataDto;
    }

    /**
     * @param empId
     * @param locationId
     * @return
     */
    private AuditGraphResultDTO generateEmptyObject(String empId, String locationId) {
        AuditGraphResultDTO emptyDto = new AuditGraphResultDTO()
                .setEmployerIdentifier(empId)
                .setLocationIdentifier(locationId)
                .setHistoricalI9sUploaded(0)
                .setNoOfI9sWithIssues(0)
                .setTotalI9sResolved(0)
                .setTotalNoOfIssues(0)
                .setPotentialFineRisk(BigDecimal.ZERO);
        return emptyDto;
    }

    private enum Frequency {
        year, month, week
    }
}
