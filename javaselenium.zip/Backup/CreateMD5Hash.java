package com.equifax.ews.I9RescueServiceUtilities;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.DigestUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@Slf4j
public class CreateMD5Hash {

    String content;
    String content_with_outSpace;

    public String removeWhiteSpace(String data) {
        return data.replaceAll("\\s", "");
    }

    public String getMd5Hash(String fileName) throws IOException {
        content = new String(Files.readAllBytes(Paths.get(fileName)));
        content_with_outSpace = removeWhiteSpace(content);
        return DigestUtils.md5DigestAsHex(content_with_outSpace.getBytes());
    }

}
