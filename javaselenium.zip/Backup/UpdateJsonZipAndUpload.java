package com.equifax.ews.I9RescueServiceUtilities;

import com.equifax.ews.I9RescueServiceUtilities.*;
import com.equifax.ews.utilities.FolderFileManagement;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
//import cucumber.api.DataTable;
import io.cucumber.datatable.DataTable;
import gherkin.formatter.model.DataTableRow;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.equifax.ews.I9RescueServiceUtilities.SetPropertyBase.*;

//import gherkin.formatter.model.DataTableRow;

@Slf4j
public class UpdateJsonZipAndUpload {

    FolderFileManagement folderObj = new FolderFileManagement();
    ConnectToGoogleStorage cloudUpload = new ConnectToGoogleStorage();
    String sourceFolderPath = null;
    String sourceFolderPathEncrypted = null;
    CreateMD5Hash hashValue;
    ZipUtils appZip;
    Storage storage;
    public static String randomName;

    public UpdateJsonZipAndUpload() {
        storage = StorageOptions.newBuilder().setProjectId("ews-es-i9-npe-00c4").build().getService();
    }

    public String i9JsonCreationForAPITest(String version, String arg1, String arg2, String arg3, String arg4, String arg5, String imageFile, String employerType) {
        System.out.println("Java method is started execution");
        SetPropertyBase.assignPropValues();
        sourceFolderPath = folderObj.createFolder(SOURCE_FOLDER, "InputIngestionFolder");
        sourceFolderPathEncrypted = folderObj.createFolder(SOURCE_FOLDER, "EncryptedZipToUpload");
        String boolContent = "";
        String employeeJsonFileName = "apiTest" + ".json";
        String destinationJsonFile = sourceFolderPath + File.separator + employeeJsonFileName;
        String inputTemplateFile = CURRENTPATH + "/src/test/resources/TestData/APITestData" + File.separator + version + "_Template.json";
        try {

            HashMap<String, Object> jsonFieldUpdate = new HashMap<>();

            if (employerType.equalsIgnoreCase("Auditor"))
                jsonFieldUpdate.put("employerIdentifier", EMPLOYER_IDENTIFIER);
            else if (employerType.equalsIgnoreCase("Converter"))
                jsonFieldUpdate.put("employerIdentifier", EMPLOYER_IDENTIFIER_CONVERTER);

            jsonFieldUpdate.put("paperFormI9.sectionOne.firstName", arg1);
            jsonFieldUpdate.put("paperFormI9.sectionOne.lastName", arg2);
            jsonFieldUpdate.put("paperFormI9.sectionOne.zipCode", arg3);
            jsonFieldUpdate.put("paperFormI9.sectionOne.dateOfBirth", arg4);
            jsonFieldUpdate.put("paperFormI9.sectionOne.socialSecurityNumber", arg5);

            updateJson(inputTemplateFile, destinationJsonFile, jsonFieldUpdate);
            /* generate MD hash*/
            MD5hashJson();
            /* Copy associated files */
            if (imageFile.equalsIgnoreCase("HighResolutionI9.tiff")) {
                copyAssociatedFiles_HighResolutionImage("Emp01.txt", "Emp01.tiff", "Emp01.tif");
            } else if (imageFile.equalsIgnoreCase("NoImage")) {
                copyAssociatedFiles_NoImage("Emp01.txt", "NoImage", "Emp01.tif");
            } else {
                copyAssociatedFiles("Emp01.txt", "Emp01.tiff", "Emp01.tif");
            }
            /* Zip the folder */
            zipFolder();
            /* Encrypt the Zip file */
            encryptZipFiles();
            /* upload zip to cloud */
            if (moveFilesToStorage()) {
                return findI9Identifier(BATCH_IDENTIFIER, MD5hashValue);
            }
        } catch (Exception e) {
            log.error("Error occurred while creating the json file");
            log.error("Error reported is", e);
        }
        return null;
    }


    public void MD5hashJson() throws IOException {
        String employeeJsonFileName = "uiTest.json";
        String destinationJsonFile = sourceFolderPath + File.separator + employeeJsonFileName;
        hashValue = new CreateMD5Hash();
        MD5hashValue = hashValue.getMd5Hash(destinationJsonFile);
        log.info("The MD5 hash value :  " + MD5hashValue);
    }

    public void copyAssociatedFiles(String PayrollFileName, String ImageFileName, String SuppImageFileName) {
        EMPLOYEE_PDF_FILEPATH = sourceFolderPath + File.separator + PDF_FILENAME_TO_ZIP + ".pdf";
        EMPLOYEE_PAYROLL_FILEPATH = sourceFolderPath + File.separator + PayrollFileName;
        EMPLOYEE_IMAGE_FILEPATH = sourceFolderPath + File.separator + ImageFileName;
        EMPLOYEE_SUPPORTING_IMAGE_FILEPATH = sourceFolderPath + File.separator + SuppImageFileName;
        folderObj.copyFile(EMPLOYEE_TEMPLATE_PDF_FILEPATH, EMPLOYEE_PDF_FILEPATH);
        folderObj.copyFile(EMPLOYEE_TEMPLATE_IMAGE_FILEPATH, EMPLOYEE_IMAGE_FILEPATH);
        folderObj.copyFile(EMPLOYEE_TEMPLATE_PAYROLL_FILEPATH, EMPLOYEE_PAYROLL_FILEPATH);
        folderObj.copyFile(EMPLOYEE_TEMPLATE_SUPPORTING_IMAGE_FILEPATH, EMPLOYEE_SUPPORTING_IMAGE_FILEPATH);
    }

    public void copyAssociatedFiles_HighResolutionImage(String PayrollFileName, String ImageFileName, String SuppImageFileName) {
        EMPLOYEE_PDF_FILEPATH = sourceFolderPath + File.separator + PDF_FILENAME_TO_ZIP + ".pdf";
        EMPLOYEE_PAYROLL_FILEPATH = sourceFolderPath + File.separator + PayrollFileName;
        EMPLOYEE_IMAGE_FILEPATH = sourceFolderPath + File.separator + ImageFileName;
        EMPLOYEE_SUPPORTING_IMAGE_FILEPATH = sourceFolderPath + File.separator + SuppImageFileName;
        folderObj.copyFile(EMPLOYEE_TEMPLATE_PDF_FILEPATH, EMPLOYEE_PDF_FILEPATH);
        folderObj.copyFile(EMPLOYEE_TEMPLATE_IMAGE_FILEPATH_HIGHRESOLUTION, EMPLOYEE_IMAGE_FILEPATH);
        folderObj.copyFile(EMPLOYEE_TEMPLATE_PAYROLL_FILEPATH, EMPLOYEE_PAYROLL_FILEPATH);
        folderObj.copyFile(EMPLOYEE_TEMPLATE_SUPPORTING_IMAGE_FILEPATH, EMPLOYEE_SUPPORTING_IMAGE_FILEPATH);
    }

    public void copyAssociatedFiles_NoImage(String PayrollFileName, String ImageFileName, String SuppImageFileName) {
        EMPLOYEE_PDF_FILEPATH = sourceFolderPath + File.separator + PDF_FILENAME_TO_ZIP + ".pdf";
        EMPLOYEE_PAYROLL_FILEPATH = sourceFolderPath + File.separator + PayrollFileName;
        EMPLOYEE_SUPPORTING_IMAGE_FILEPATH = sourceFolderPath + File.separator + SuppImageFileName;
        folderObj.copyFile(EMPLOYEE_TEMPLATE_PDF_FILEPATH, EMPLOYEE_PDF_FILEPATH);
        folderObj.copyFile(EMPLOYEE_TEMPLATE_PAYROLL_FILEPATH, EMPLOYEE_PAYROLL_FILEPATH);
        folderObj.copyFile(EMPLOYEE_TEMPLATE_SUPPORTING_IMAGE_FILEPATH, EMPLOYEE_SUPPORTING_IMAGE_FILEPATH);
    }

    public void zipFolder() {
        appZip = new ZipUtils(sourceFolderPath);
        appZip.generateFileList(new File(sourceFolderPath));
        TIME_FORMAT = appZip.addTimestamp();

        OUTPUT_ZIP_FILE_PATH = sourceFolderPath + File.separator + TEST_CASE_ID + "_" + TIME_FORMAT + ".zip";
        OUTPUT_ZIP_FILE_PATH_ENCRYPTED =
                sourceFolderPathEncrypted + File.separator + TEST_CASE_ID + "_" + TIME_FORMAT + ".zip";
        BATCH_IDENTIFIER = TEST_CASE_ID + "_" + TIME_FORMAT;
        OUTPUT_ZIP_FILE = BATCH_IDENTIFIER + ".zip";


        appZip.zipIt(OUTPUT_ZIP_FILE_PATH);
    }

    public void encryptZipFiles() {

        CryptoServiceImpl objCryptoServiceImpl = new CryptoServiceImpl();
        objCryptoServiceImpl.encryptFile(OUTPUT_ZIP_FILE_PATH, OUTPUT_ZIP_FILE_PATH_ENCRYPTED);
    }

    public boolean moveFilesToStorage() {
        try {
            BlobInfo blobInfo = BlobInfo.newBuilder(GCP_INGESTION_BUCKET, OUTPUT_ZIP_FILE)
                    .setContentType("application/octet-stream")
                    .setContentDisposition(String.format("attachment; filename=\"%s\"", OUTPUT_ZIP_FILE)).build();
            storage.create(blobInfo, Files.readAllBytes(Paths.get(OUTPUT_ZIP_FILE_PATH_ENCRYPTED)));
            return true;
        } catch (Exception exception) {
            log.error(" Exception in moving files to storage");
        }
        return false;
    }

    public static void updateJson(String inputPath, String outputPath, HashMap<String, Object> value) {
        ObjectMapper mapper = new ObjectMapper();
        JSONParser parser = new JSONParser();
        try {
            Object obj = parser.parse(new FileReader(String.valueOf(Paths.get(inputPath))));
            JSONObject jsonObject = (JSONObject) obj;
            value.forEach((k, v) -> {
                DocumentContext doc = JsonPath.parse(jsonObject);
                doc.set(k, v);
            });
            FileWriter file = new FileWriter(String.valueOf(Paths.get(outputPath)));
            file.write(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject));
            file.close();
        } catch (ParseException | IOException e) {
            e.printStackTrace();
        }
    }

    public String findI9Identifier(String batchIdentifier, String i9Digest) {
        ConnectToFireStore readFireStore = new ConnectToFireStore();
        List<QueryDocumentSnapshot> querySnapshotDocuments = null;
        String searchKey = "i9Identifier";
        String i9Identifier = "";
        List<String> parameters = new ArrayList<>();
        String QueryValue_1 = batchIdentifier;
        String QueryValue_2 = i9Digest;

        parameters.add(0, "batchIdentifier");
        parameters.add(1, QueryValue_1);
        parameters.add(2, "i9Digest");
        parameters.add(3, QueryValue_2);

        querySnapshotDocuments = readFireStore.retrieveFireStoreDocuments("Converter", parameters);
        i9Identifier = readFireStore.filterFireStoreResult(searchKey, querySnapshotDocuments);

        return i9Identifier;

    }

    public String i9JsonCreationForAPITest_WithAnyFields(String version, String i9Fields, String employerType) {
        System.out.println("Java method is started execution");
        SetPropertyBase.assignPropValues();
        sourceFolderPath = folderObj.createFolder(SOURCE_FOLDER, "InputIngestionFolder");
        sourceFolderPathEncrypted = folderObj.createFolder(SOURCE_FOLDER, "EncryptedZipToUpload");
        String employeeJsonFileName = "apiTest" + ".json";
        String destinationJsonFile = sourceFolderPath + File.separator + employeeJsonFileName;
        String inputTemplateFile = CURRENTPATH + "/src/test/resources/TestData/I9Templates" + File.separator + version + "_Template.json";
        try {

            HashMap<String, Object> jsonFieldUpdate = new HashMap<>();
            if (employerType.equalsIgnoreCase("Auditor"))
                jsonFieldUpdate.put("employerIdentifier", EMPLOYER_IDENTIFIER);
            else if (employerType.equalsIgnoreCase("Converter"))
                jsonFieldUpdate.put("employerIdentifier", EMPLOYER_IDENTIFIER_CONVERTER);
            String[] arrSplit = i9Fields.split(",");
            for (int i = 0; i < arrSplit.length; i++) {
                String[] arrFieldNvalue = arrSplit[i].split(":");

                if ((arrFieldNvalue[1].equalsIgnoreCase("true")) || (arrFieldNvalue[1].equalsIgnoreCase("false"))) {
                    boolean boolContent = Boolean.parseBoolean(arrFieldNvalue[1]);
                    jsonFieldUpdate.put(arrFieldNvalue[0], boolContent);
                } else if (arrFieldNvalue[1].equalsIgnoreCase("currentdate")) {
                    String strCurrDate = getDate("MM/dd/yyyy", 0);
                    jsonFieldUpdate.put(arrFieldNvalue[0], strCurrDate);
                } else {
                    jsonFieldUpdate.put(arrFieldNvalue[0], arrFieldNvalue[1]);
                }

            }
//            jsonFieldUpdate.put("employerIdentifier",EMPLOYER_IDENTIFIER);
//            jsonFieldUpdate.put("paperFormI9.sectionOne.firstName", arg1);
//            jsonFieldUpdate.put("paperFormI9.sectionOne.lastName", arg2);
//            jsonFieldUpdate.put("paperFormI9.sectionOne.zipCode", arg3);
//            jsonFieldUpdate.put("paperFormI9.sectionOne.dateOfBirth", arg4);
//            jsonFieldUpdate.put("paperFormI9.sectionOne.socialSecurityNumber", arg5);

            updateJson(inputTemplateFile, destinationJsonFile, jsonFieldUpdate);
            /* generate MD hash*/
            MD5hashJson();
            /* Copy associated files */
            copyAssociatedFiles("Emp01.txt", "Emp01.tiff", "Emp01.tif");
            /* Zip the folder */
            zipFolder();
            /* Encrypt the Zip file */
            encryptZipFiles();
            /* upload zip to cloud */
            if (moveFilesToStorage()) {
                return findI9Identifier(BATCH_IDENTIFIER, MD5hashValue);
            }
        } catch (Exception e) {
            log.error("Error occurred while creating the json file");
            log.error("Error reported is", e);
            e.printStackTrace();
        }
        return null;
    }

    public void setTheTestCaseName(String testCaseName) {
        TEST_CASE_ID = testCaseName;
    }

    public String getDate(String format, int dateDiff) {
        String strDate = "";
        try {
            Date today = new Date();
            Calendar cal = new GregorianCalendar();
            cal.setTime(today);
            cal.add(Calendar.DAY_OF_MONTH, dateDiff);
            Date convertedDate = cal.getTime();
            SimpleDateFormat formatter = new SimpleDateFormat(format);
            strDate = formatter.format(convertedDate);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return strDate;
    }

    public String randomStringGenerate() {

        byte[] array = new byte[7];
        new Random().nextBytes(array);
        return new String(array, Charset.forName("UTF-8"));

    }

    public String getRandomName() {

        if (randomName == null)
            randomName = randomStringGenerate();

        return randomName;


    }

    public String i9JsonCreationForUITest(String employerType, String i9Version, DataTable testData) {
        System.out.println("i9 creation method is started execution");
        String boolContent = "";
        String version = "";
        assignPropValues();
        sourceFolderPath = folderObj.createFolder(SOURCE_FOLDER, "InputIngestionFolder");
        sourceFolderPathEncrypted = folderObj.createFolder(SOURCE_FOLDER, "EncryptedZipToUpload");
        String employeeJsonFileName = "uiTest" + ".json";
        String destinationJsonFile = sourceFolderPath + File.separator + employeeJsonFileName;
        try {
            HashMap<String, Object> jsonFieldUpdate = new HashMap<>();
            //List<DataTableRow> dataTableRows = testData.getGherkinRows();
            List<List<String>> dataTableRows = testData.asLists(String.class);
            int tableRows = dataTableRows.size();
            String[] arrOfKeys = new String[tableRows];
            String[] arrOfValues = new String[tableRows];
            for (int itr = 0; itr < tableRows; itr++) {
//                arrOfKeys[itr] = dataTableRows.get(itr).getCells().get(0);
//                arrOfValues[itr] = dataTableRows.get(itr).getCells().get(1);
                arrOfKeys[itr] = dataTableRows.get(itr).get(0);
                arrOfValues[itr] = dataTableRows.get(itr).get(1);
                if (arrOfKeys[itr].equalsIgnoreCase("supportingDocuments")) {
                    jsonFieldUpdate.put(arrOfKeys[itr], new String[]{arrOfValues[itr]});
                    continue;
                } else if (arrOfKeys[itr].equalsIgnoreCase("version")) {
                    version = arrOfValues[itr];
                } else if (arrOfValues[itr].contains("Boolean")) {
                    boolContent = arrOfValues[itr].split("\\.")[1];
                    if (boolContent.equalsIgnoreCase("true")) {
                        jsonFieldUpdate.put(arrOfKeys[itr], true);
                        continue;
                    } else if (boolContent.equalsIgnoreCase("false")) {
                        jsonFieldUpdate.put(arrOfKeys[itr], false);
                        continue;
                    } else {
                        log.info("Invalid entry for the boolean field " + arrOfKeys[itr]);
                        continue;
                    }
                }
                jsonFieldUpdate.put(arrOfKeys[itr], arrOfValues[itr]);
            }
            if (employerType.equalsIgnoreCase("Auditor"))
                jsonFieldUpdate.put("employerIdentifier", EMPLOYER_IDENTIFIER);
            else if (employerType.equalsIgnoreCase("Converter"))
                jsonFieldUpdate.put("employerIdentifier", EMPLOYER_IDENTIFIER_CONVERTER);
            String inputTemplateFile = CURRENTPATH + "/src/test/resources/TestData/I9Templates" + File.separator + i9Version + "_Template.json";
            updateJson(inputTemplateFile, destinationJsonFile, jsonFieldUpdate);
            /* generate MD hash*/
            MD5hashJson();
            /* Copy associated files */
            copyAssociatedFiles("Emp01.txt", "Emp01.tiff", "Emp01.tif");
            /* Zip the folder */
            zipFolder();
            /* Encrypt the Zip file */
            encryptZipFiles();
            /* upload zip to cloud */
            if (moveFilesToStorage()) {
                return findI9Identifier(BATCH_IDENTIFIER, MD5hashValue);
            }
        } catch (Exception e) {
            log.error("Error occurred while creating the json file");
            log.error("Error reported is", e);
            e.printStackTrace();
        }
        return null;
    }

    public String i9JsonCreationForAPITest_WithAnyFields_2(DataTable testData) {
        System.out.println("i9 creation method is started execution");
        String boolContent = "";
        return null;
    }
}
