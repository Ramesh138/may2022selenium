package com.equifax.ews.env;

import java.io.FileInputStream;
import java.util.Properties;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PropertyConfigurationReader {

    private static Properties prop = null;
    public static final String PROPERTIES_FILE_PATH = "";

    public Properties getProp() {

        return prop;
    }

    public static String fetchPropertyFile(){
        String env = System.getProperty("env")==null? "qa":System.getProperty("env");
        String propertyFilePath = "/src/test/resources/appconfigs/" + env + ".properties";
        return propertyFilePath;
    }

    public static Properties ConfigurationReader() {

        try {
            prop = new Properties();
            FileInputStream fileInputStream = new FileInputStream(
                System.getProperty("user.dir") + fetchPropertyFile());
            prop.load(fileInputStream);


        } catch (Exception e) {
            System.out.println(e.getMessage());
            log.error("Issue in reading property file");
        }

        return prop;

    }

}