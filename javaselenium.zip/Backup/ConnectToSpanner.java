package com.equifax.ews.I9RescueServiceUtilities;


import com.equifax.ews.I9RescueServiceUtilities.SetPropertyBase;
import com.google.cloud.spanner.*;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Slf4j
public class ConnectToSpanner extends SetPropertyBase {

    SpannerOptions options = SpannerOptions.newBuilder().build();
    Spanner spanner = options.getService();
    ResultSet resultSet;
    DatabaseId db;

    public static final String YEARLY_AUDIT_GRAPH_RESULT_BY_EMPLOYER_AND_LOC_IDENTIFIER = "SELECT WS.year AS year ,"
        + "@employerIdentifier AS employerIdentifier,"
        + "@locIdentifier AS locationIdentifier,"
        + "COUNT(HI.EMPLYR_IDENTIFIER) AS historicalI9sUploaded,"
        + "SUM(case when HI.AUDIT_STATUS = FALSE then 1 else 0 end) AS noOfI9sWithIssues,"
        + "SUM(case when HI.AUDIT_STATUS = TRUE then 1 else 0 end) AS noOfI9sWithoutIssues,"
        + "SUM(AE.count) as totalNoOfIssues "
        + "FROM (SELECT EXTRACT(YEAR FROM date) AS year "
        + "FROM UNNEST(GENERATE_DATE_ARRAY(DATE(@startDate), "
        + "DATE(@endDate))) AS date GROUP BY year) WS "
        + "LEFT OUTER JOIN (I9_INSP_HEADER_INFO HI "
        + "INNER JOIN (SELECT I9_IDENTIFIER,count(AUDIT_ERROR_ID) AS "
        + "count FROM I9_INSP_AUDIT_ERRORS GROUP BY I9_IDENTIFIER) AE "
        + "ON HI.I9_IDENTIFIER = AE.I9_Identifier) "
        + "ON WS.year = EXTRACT(YEAR FROM HI.LOAD_DT) AND "
        + "HI.EMPLYR_IDENTIFIER= @employerIdentifier AND "
        + "HI.LOC_IDENTIFIER = @locIdentifier AND "
        + "HI.LOAD_DT BETWEEN @startDate AND @endDate "
        + "GROUP BY employerIdentifier,locationIdentifier,year "
        + "ORDER BY year";
    public static final String YEARLY_AUDIT_GRAPH_RESULT_BY_EMPLOYER = "SELECT WS.year AS year ,"
        + "@employerIdentifier AS employerIdentifier,"
        + "@locIdentifier AS locationIdentifier,"
        + "COUNT(HI.EMPLYR_IDENTIFIER) AS historicalI9sUploaded,"
        + "SUM(case when HI.AUDIT_STATUS = FALSE then 1 else 0 end) AS noOfI9sWithIssues,"
        + "SUM(case when HI.AUDIT_STATUS = TRUE then 1 else 0 end) AS noOfI9sWithoutIssues,"
        + "SUM(AE.count) as totalNoOfIssues "
        + "FROM (SELECT EXTRACT(YEAR FROM date) AS year "
        + "FROM UNNEST(GENERATE_DATE_ARRAY(DATE(@startDate), "
        + "DATE(@endDate))) AS date GROUP BY year) WS "
        + "LEFT OUTER JOIN (I9_INSP_HEADER_INFO HI "
        + "INNER JOIN (SELECT I9_IDENTIFIER,count(AUDIT_ERROR_ID) AS "
        + "count FROM I9_INSP_AUDIT_ERRORS GROUP BY I9_IDENTIFIER) AE "
        + "ON HI.I9_IDENTIFIER = AE.I9_Identifier) "
        + "ON WS.year = EXTRACT(YEAR FROM HI.LOAD_DT) AND "
        + "HI.EMPLYR_IDENTIFIER= @employerIdentifier AND "
        + "HI.LOAD_DT BETWEEN @startDate AND @endDate "
        + "GROUP BY employerIdentifier,year "
        + "ORDER BY year";
    public ConnectToSpanner() {
         db = DatabaseId.of(PROJECT_ID_SPANNER, SPANNER_DB_INSTANCE, SPANNER_DATABASE);
    }

    public void connectToSpannerAndGetData() {
        try {
            DatabaseClient dbClient = spanner.getDatabaseClient(db);
            //DatabaseAdminClient dbAdminClient = spanner.getDatabaseAdminClient();
            //InstanceAdminClient instanceAdminClient = spanner.getInstanceAdminClient();
            try (ResultSet resultSet =
                         dbClient
                                 .singleUse() // Execute a single read or query against Cloud Spanner.
                                 .executeQuery(Statement.of("SELECT START_DATE_STR FROM I9_INSP_PAPER_I9_DATA Where I9_IDENTIFIER='c87d74cd-9e4a-4eaf-8e5e-c1bcecae9c3e'"))) {
                while (resultSet.next()) {
                    System.out.printf("The value of start date is: "+ resultSet.getString(0) );
                }
            }
        } finally {
            spanner.close();
        }
    }

    public Statement createStatementForSingleParameter(String query, String paramName, String paramValue) {

        Statement statement =
                Statement.newBuilder(query)
//                        .bind("i9Identifier")
//                        .to("ad72d476-e42e-4875-9d14-b20d827879e6X")
                        .bind(paramName)
                        .to(paramValue)
                        .build();
        return statement;
    }
    public List<Object> executeQuery(Statement queryStatement, String colName, String colType){
        //boolean existFlag = false;
        List<Object> objList = new ArrayList<>();
          DatabaseClient dbClient = spanner.getDatabaseClient(db);
             resultSet = dbClient.singleUse().executeQuery(queryStatement) ;
                while (resultSet.next()) {
                    if (colType == "string"){
                        objList.add(resultSet.getString(colName));
                    }
                }

            return objList;
    }
    public void closeSpannerObjects(){
        resultSet.close();
        spanner.close();

    }

    public boolean isRecordExist(ResultSet objResultSet){
        boolean existFlag = false;
        try {
            if (objResultSet.next()) {
                existFlag=true;
            }
        }catch(NullPointerException e){

        }
        return existFlag;
    }




}
