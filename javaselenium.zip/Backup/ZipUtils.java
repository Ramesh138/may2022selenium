package com.equifax.ews.I9RescueServiceUtilities;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/*
 This utility is used to zip operation, timestamp add etc
*/

@Slf4j
public class ZipUtils extends SetPropertyBase{

    private List <String> fileList;
    private static String SOURCE_FOLDER;
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
    File oldFile;
    String oldFilePath;

    public ZipUtils(String sourceFolder) {
        fileList = new ArrayList < String > ();
        SOURCE_FOLDER = sourceFolder;
    }

    public void zipIt(String zipFile){
        byte[] buffer = new byte[1024];
        try{
            FileOutputStream fos = new FileOutputStream(zipFile);
            ZipOutputStream zos = new ZipOutputStream(fos);
            log.info("Zip operation Started");
            for(String file : this.fileList){
                    ZipEntry ze = new ZipEntry(file);
                    zos.putNextEntry(ze);
                    FileInputStream in =
                        new FileInputStream(SOURCE_FOLDER + File.separator + file);
                    int len;
                    while ((len = in.read(buffer)) > 0) {
                        zos.write(buffer, 0, len);
                    }
                    in.close();

                    oldFilePath = SOURCE_FOLDER + File.separator + file;
                    oldFile = new File(oldFilePath);
                    if (oldFile.delete()) {

                        log.info("The file deleted from the parent location after zipping : " + file);
                    } else {
                        log.info("Not able to delete the file from the parent location after zipping : " + file);
                    }
            }
            zos.closeEntry();
            zos.close();
            if(INVALID_FOLDER_PATH!= null)
            {

                oldFilePath = INVALID_FOLDER_PATH;
                oldFile = new File(oldFilePath);
                oldFile.delete();
            }
            log.info("Zip operation done");
        }catch(IOException ex){
            ex.printStackTrace();
            log.error("IO- Exception in Zip operation");
        }
    }

    public void generateFileList(File node) {
        // add file only
        if (node.isFile() && (!node.getName().contains(".zip"))) {
            fileList.add(generateZipEntry(node.toString()));
        }
        if (node.isDirectory()) {
            String[] subNote = node.list();
            for (String filename: subNote) {
                generateFileList(new File(node, filename));
            }
        }
    }

    private String generateZipEntry(String file) {
        return file.substring(SOURCE_FOLDER.length() + 1, file.length());
    }

    public String addTimestamp() {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        return TIME_FORMAT.format(timestamp).toString();

    }



}
