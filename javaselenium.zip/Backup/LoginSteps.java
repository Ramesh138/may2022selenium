package com.equifax.ews.step_def;

import com.equifax.ews.pageObjects.LoginPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.qameta.allure.Attachment;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LoginSteps {

    private LoginPage loginPage;
    public LoginSteps(){

        loginPage = new LoginPage();


    }

    @Given("Helen navigate to login page")
    @Attachment
    public void iNavigateLoginPage() {

        loginPage.launch();
    }
    @Given("Helen navigate to CSA login page")
    public void csaNavigateLoginPage() {

        loginPage.csalaunch();
    }
    @And("logs into the portal")
    @Attachment
    public void logsIntoThePortal() {

        loginPage.login();
    }

    @And("logs into the portal as {string} role")
    public void logsIntoThePortalAsRole(String userRole) {

        loginPage.login(userRole);

    }

}
