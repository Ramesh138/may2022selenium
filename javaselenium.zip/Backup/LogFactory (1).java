package com.equifax.ews.logging;

import com.equifax.ews.logging.impl.Log4jLogger;
import com.equifax.ews.logging.impl.Slf4jLogger;
import org.apache.log4j.Level;
import org.apache.log4j.PropertyConfigurator;
import org.slf4j.LoggerFactory;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

/**
 * Factory implementation for logging.
 */
public final class LogFactory {
    /**
     * Properties object.
     */
    private static Properties properties = new Properties();
    private static Logger logger = LogFactory.getLogger(LogFactory.class);

    /**
     * Private constructor for utility class.
     */
    private LogFactory() {
    }

    /**
     * Read properties from properties file.
     */
    private static void readProperties() {
        properties = new Properties();
        try {
            properties.load(new FileReader("src\\test\\resources\\suite.properties"));
        } catch (IOException e) {
            logger.printStackTrace(e);
        }

        if (properties.getProperty("logger").equalsIgnoreCase("log4j")) {
            PropertyConfigurator.configure("src\\test\\resources\\com\\Equifax\\logging\\log4j.properties");
        }
    }

    /**
     * Logger factory method to get logger.
     *
     * @param c - Class parameter.
     * @return - Logger
     */
    public static com.equifax.ews.logging.Logger getLogger(final Class c) {
        readProperties();
        String logger = properties.getProperty("logger");
        String enableLogger = properties.getProperty("logger.enable");
        String loggerLevel = properties.getProperty("logger.level");

        com.equifax.ews.logging.Logger loggerObject = getLog4jLogger(c, enableLogger, loggerLevel);

        if (logger.equalsIgnoreCase("Slf4j")) {
            loggerObject = getSlf4jLogger(c);
        } else if (logger.equalsIgnoreCase("Log4j")) {
            loggerObject = getLog4jLogger(c, enableLogger, loggerLevel);
        }
        return loggerObject;
    }

    /**
     * Get slf4j logger.
     *
     * @param c - Class.
     * @return - Logger object.
     */
    private static Logger getSlf4jLogger(final Class c) {
        return new Slf4jLogger(LoggerFactory.getLogger(c));
    }

    /**
     * Get Log4j logger.
     *
     * @param c            - Class
     * @param enableLogger - String denoting logger enable.
     * @param logLevel     - Logger level.
     * @return - Logger object.
     */
    private static Logger getLog4jLogger(final Class c, final String enableLogger, final String logLevel) {
        org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(c);
        if (enableLogger.equalsIgnoreCase("true")) {
            logger.setLevel(Level.toLevel(logLevel));
        } else {
            logger.setLevel(Level.OFF);
        }
        return new Log4jLogger(logger);
    }
}
