package com.equifax.ews.I9RescueServiceUtilities;

import com.bettercloud.vault.Vault;
import com.bettercloud.vault.VaultConfig;
import com.bettercloud.vault.VaultException;


public class VaultConnect  extends SetPropertyBase{
    static String vaulttoken;
    static String vaulthost;
    public static String USEREMAIL;
    public static String USERPIN;
    public static String USERCODE;
    public static String SUSER;
    public static String SPIN;

   public static String[] setCredentials(String userType){
       SetPropertyBase.assignPropValues();
      if(userType.equalsIgnoreCase("Auditor")) {
          USEREMAIL = getSecret(getVaultConnection(), VAULT_SECRETKEYPATH, VAULT_USERNAMEKEY);
          USERPIN = getSecret(getVaultConnection(), VAULT_SECRETKEYPATH, VAULT_PASSWORDKEY);
      }
      else if (userType.equalsIgnoreCase("Converter")) {

          USEREMAIL = getSecret(getVaultConnection(), VAULT_SECRETKEYPATH, VAULT_CONVERT_USERNAMEKEY);
          USERPIN = getSecret(getVaultConnection(), VAULT_SECRETKEYPATH, VAULT_CONVERT_PASSWORDKEY);
      }

       USERCODE = getSecret(getVaultConnection(), VAULT_SECRETKEYPATH, VAULT_USERCODE);
       SUSER = getSecret(getVaultConnection(), VAULT_SECRETKEYPATH, VAULT_SUSER);
       SPIN = getSecret(getVaultConnection(), VAULT_SECRETKEYPATH, VAULT_SPIN);
       String [] ArrCredential = {USEREMAIL,USERPIN,USERCODE,SUSER,SPIN};
       return ArrCredential;
   }

   public static Vault getVaultConnection() {

    Vault vault = null;
    try {
        String vaultToken = System.getProperty("vaultToken")==null? VAULT_TOKEN:System.getProperty("vaultToken");

        final VaultConfig config = new VaultConfig().address(VAULT_ADDR).
            nameSpace(VAULT_NAMESPACE).token(vaultToken).build();
        //final VaultConfig config = new VaultConfig().address("https://vault.uat.use1.crypto.gcp.efx").nameSpace("ews-es-eev/rescue").token("s.v3RXgk5AP2suLJnh8JUO1s1n").build();

        vault = new Vault(config);

        /*final Vault vault = new Vault(config);
        AuthResponse login = vault.auth().loginByAppRole(roleId, secretId);
        return login.getAuthClientToken();*/

     /*   inal VaultConfig config = new VaultConfig().address(...).token(...).build();
     * final Vault vault = new Vault(config);
     * final AuthResponse response = vault.auth().createToken(new TokenRequest().withTtl("1h"));
     *
     * final String token = response.getAuthClientToken();*/

        /*final AuthResponse response = vault.auth().loginByCert();
         final String token = response.getAuthClientToken();*/
    } catch (VaultException e) {
        e.printStackTrace();
        System.out.println("Exception thrown: " + e);
    }

    return vault;
}

public static String getSecret(Vault vault, String secretKeyPath,String secretKey) {

    String keyValue = null;
    try {

        keyValue = vault.logical()
            .read(secretKeyPath)
            .getData().get(secretKey);
       // System.out.format("value key in " + secretKeyPath +" is " + keyValue + "\n");
    } catch (VaultException e) {
        e.printStackTrace();
        System.out.println("Exception thrown: " + e);
    }
    return keyValue;
}

}
