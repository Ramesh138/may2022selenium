package com.equifax.ews.I9RescueServiceUtilities;

import com.equifax.ews.env.PropertyConfigurationReader;

import java.io.*;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.bouncycastle.bcpg.CompressionAlgorithmTags;
import org.bouncycastle.bcpg.SymmetricKeyAlgorithmTags;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.*;
import org.bouncycastle.openpgp.operator.jcajce.JcaKeyFingerprintCalculator;
import org.bouncycastle.openpgp.operator.jcajce.JcePGPDataEncryptorBuilder;
import org.bouncycastle.openpgp.operator.jcajce.JcePublicKeyKeyEncryptionMethodGenerator;
import org.bouncycastle.util.io.Streams;

@Slf4j
public class CryptoServiceImpl extends SetPropertyBase {



    private PGPPublicKey readPublicKey() throws IOException, PGPException {
        Properties prop = PropertyConfigurationReader.ConfigurationReader();
        JcaKeyFingerprintCalculator fingerPrintCalculator = new JcaKeyFingerprintCalculator();
        PGPPublicKey publicKey = null;
        try (InputStream inputStream = PGPUtil.getDecoderStream(new FileInputStream(prop.getProperty("publicKey").toString()))) {
            PGPPublicKeyRingCollection keyRingCollection = new PGPPublicKeyRingCollection(
                    inputStream, fingerPrintCalculator);
            Iterator<PGPPublicKeyRing> keyRings = keyRingCollection.getKeyRings();
            while (null == publicKey && keyRings.hasNext()) {
                publicKey = this.getPgpPublicKey(keyRings);
            }
        } catch (Exception ex) {
            log.error("Exception finding PublicKey: ", ex);
            throw ex;
        }
        return publicKey;
    }

    /**
     * Retrieves the public key from the key rings
     *
     * @param keyRings
     * @return
     */
    private PGPPublicKey getPgpPublicKey(Iterator<PGPPublicKeyRing> keyRings) {
        PGPPublicKey publicKey = null;
        PGPPublicKeyRing kRing = keyRings.next();
        Iterator<PGPPublicKey> kIt = kRing.getPublicKeys();
        while (null == publicKey && kIt.hasNext()) {
            PGPPublicKey k = kIt.next();
            if (k.isEncryptionKey()) {
                publicKey = k;
            }
        }
        return publicKey;
    }




    public Boolean encryptFile(String inputFileNamePath, String outPutFileNamePath) {
        log.info("-----Start of PGP Encryption-----");
        BouncyCastleProvider provider = new BouncyCastleProvider();

        try (OutputStream outputStream =new FileOutputStream(outPutFileNamePath)) {

            PGPPublicKey publicKey = this.readPublicKey();
            Security.addProvider(provider);

            final ByteArrayInputStream in = new ByteArrayInputStream(FileUtils.readFileToByteArray(new File(inputFileNamePath)));
            final ByteArrayOutputStream bOut = new ByteArrayOutputStream();
            final PGPLiteralDataGenerator literal = new PGPLiteralDataGenerator();
            final PGPCompressedDataGenerator comData = new PGPCompressedDataGenerator(CompressionAlgorithmTags.ZIP);
            final OutputStream pOut =
                    literal.open(comData.open(bOut), PGPLiteralData.BINARY, PGPLiteralData.CONSOLE, in.available(),
                            new Date());
            Streams.pipeAll(in, pOut);
            comData.close();
            final byte[] bytes = bOut.toByteArray();
            final PGPEncryptedDataGenerator generator = new PGPEncryptedDataGenerator(
                    new JcePGPDataEncryptorBuilder(SymmetricKeyAlgorithmTags.CAST5).setWithIntegrityPacket(true)
                            .setSecureRandom(
                                    new SecureRandom())
                            .setProvider(provider));
            generator.addMethod(new JcePublicKeyKeyEncryptionMethodGenerator(publicKey).setProvider(provider));
            OutputStream cOut = generator.open(outputStream, bytes.length);
            cOut.write(bytes);
            cOut.close();
            bOut.close();
            in.close();
            return true;
        } catch (Exception ex) {
            log.error("PGP Exception in encryption: ", ex);
        } finally {
            log.info("-----End of PGP Encryption-----");
        }
        return false;
    }


}
