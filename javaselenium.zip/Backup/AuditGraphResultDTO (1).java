package com.equifax.ews.I9RescueServiceUtilities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.math.BigDecimal;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Data
@Accessors(chain = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AuditGraphResultDTO {

    private String employerIdentifier;
    private int noOfI9sWithIssues;
    private BigDecimal potentialFineRisk;
    private int totalNoOfIssues;
    private int totalI9sResolved;
    @JsonInclude(Include.NON_DEFAULT)
    private int year;
    @JsonInclude(Include.NON_NULL)
    private String month;
    @JsonInclude(Include.NON_NULL)
    private String weekStart;
    private int historicalI9sUploaded;
    private String locationIdentifier;
}
