package com.equifax.ews.env;


import static java.lang.String.format;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.jsoup.helper.StringUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.ErrorHandler;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@Slf4j
public class I9RescueDriverUtil {
    private static final String CHROME = "chrome";
    private static final String FIREFOX = "firefox";
    private static final String EDGE = "edge";
    private static final String SAFARI = "safari";
    private static final String BROWSERSTACK = "browserstack";
    private static final String SAUCELAB = "saucelab";
    private static final String IE = "ie";
    private static final String HEADLESS = "headless";
    private static final String PROYX_HOST = "proxy.host";
    private static final String PROYX_PORT = "proxy.port";
    private static final String ACCESS_KEY = "access_key";
    private static final String PLATFORM = "platform";
    private static final String DESKTOP = "desktop";
    private static final String BROWSERNAME = "browserName";
    private static final String ENV = "env";
    private static final String QA = "qa";
    private static final String DEV = "dev";
    private static final String BROWSERSTACK_CONFIGS = "browserStack.configurations";
    private static final String HTTPS_PROXY_HOST = "https.proxyHost";
    private static final String HTTPS_PROXY_PORT = "https.proxyPort";
    private static final String HTTPS_PROXY_USERNAME = "https.proxyUser";
    private static final String DEFAULT_WAIT_TIME = "defaultWaitTime";
    private static final String PROPERTIES = ".properties";

    public static String currentPath = System.getProperty("user.dir");
    static String driverRelativePath = currentPath + "\\src\\test\\resources\\drivers\\";
    public static Properties prop = new Properties();


    protected static WebDriver driver = null;
    static Map<String, Object> configMap = ReadConfigurations.readConfigurations();
    //private static log log = LogFactory.getlog(I9RescueDriverUtil.class);
    private static Map<String, String> testData;
    private static Map<String, String> configData;
    private static final String PATH = "src/test/resources/drivers/chromedriver%s";
    public static String ACCESSBILITYCHECK= System.getProperty("accesbilitycheck")==null? "false" :System.getProperty("accesbilitycheck");

    static {
        try {


            log.info("Reading property configuration");
            prop = PropertyConfigurationReader.ConfigurationReader();

        } catch (Exception e) {

            log.info("exception in static block" + e );
           
        }
    }

    public static Map<String, String> getTestData() {
        return testData;
    }

    public static Map<String, Object> getConfigMap() {
        return configMap;
    }

    public static Map<String, String> getConfigData() {
        return configData;
    }




    /*
     * Returns default capabilities to all the browsers.
     *
     * @param browserName : String  (firefox or chrome or ie or edge or safari)
     * @return WebDriver
     */

    public static Object getDefaultOptions(String browserName) {
        DesiredCapabilities cap = new DesiredCapabilities();
        cap.setJavascriptEnabled(true);
        cap.setCapability("takesScreenshot", true);
        //boolean headless = (System.getProperty(HEADLESS) != null ? System.getProperty(HEADLESS) : "false").equals("true");
        boolean headless= !System.getProperty("os.name").startsWith("Windows");
        log.info("Test is running in :" + System.getProperty("os.name").toString() );

        switch (browserName.toLowerCase()) {
            case FIREFOX:
                FirefoxOptions fop = new FirefoxOptions();
                if (headless) {
                    fop.addArguments("--headless", "-safe-mode");
                }
                return fop;
            case CHROME:
                ChromeOptions cop = new ChromeOptions();
                if (headless) {
                    cop.addArguments("--headless");
                }
                cop.addArguments("--window-size=1920,1080");
                //commented for jenkins execution changes
               /* Proxy proxy = new Proxy();
                proxy.setHttpProxy("172.22.240.68:18717");
                // proxy.setHttpProxy("172.16.157.81:18717");
                cop.addArguments("--disable-gpu");
                cop.addArguments("--no-sandbox");
                cop.setProxy(proxy);*/

                cop.addArguments("enable-automation");
                cop.addArguments("--no-sandbox");
                cop.addArguments("--disable-extensions");

                cop.addArguments("--disable-dev-shm-usage");
                cop.addArguments("--disable-extensions");
                cop.addArguments("--disable-gpu");
                cop.addArguments("--ignore-certificate-errors");
                cop.setAcceptInsecureCerts(true);
                cop.setExperimentalOption("useAutomationExtension", false);


                cap.setCapability("applicationCacheEnabled", false);
                cap.setCapability(ChromeOptions.CAPABILITY, cop);

                return cop;
            case IE:
                InternetExplorerOptions ieop = (InternetExplorerOptions) getDefaultOptions(browserName);
                driver = new InternetExplorerDriver(ieop);
                return ieop;

            case EDGE:
                EdgeOptions eop = new EdgeOptions();
                if (headless) {
                    log.error("Headless Mode execution is not possible in Edge browser. Initializing browser in default view");
                }
                return eop;
            case SAFARI:
                SafariOptions sop = new SafariOptions();
                if (headless) {
                    log.error("Headless Mode execution is not possible in Safari browser. Initializing browser in default view");
                }
                return sop;
            case BROWSERSTACK:
                HashMap<String, String> browserStackConfigs = (HashMap) configMap.get(BROWSERSTACK_CONFIGS);
                cap.setCapability("name", String.valueOf(browserStackConfigs.get("name")));
                cap.setCapability("browser", String.valueOf(browserStackConfigs.get("browser")));
                cap.setCapability("browser_version", String.valueOf(browserStackConfigs.get("browser_version")));
                cap.setCapability("os", String.valueOf(browserStackConfigs.get("os")));
                cap.setCapability("os_version", String.valueOf(browserStackConfigs.get("os_version")));
                cap.setCapability("resolution", String.valueOf(browserStackConfigs.get("resolution")));
                return cap;

            case SAUCELAB:
                log.error("SACUELAB is still not available. Please select some other platform for execution.");
                break;
            default:

                break;
        }
        return new DesiredCapabilities();
    }

    private static WebDriver getDriverInstance() {
        if (driver instanceof ChromeDriver && checkIfBrowserSessionIsOpen(driver)) {
            if (((ChromeDriver) driver).getSessionId() != null)
                return driver;
        } else if ((driver instanceof FirefoxDriver) && checkIfBrowserSessionIsOpen(driver)) {
            if (((FirefoxDriver) driver).getSessionId() != null)
                return driver;
        } else if (driver instanceof EdgeDriver && (((EdgeDriver) driver).getSessionId() != null) && checkIfBrowserSessionIsOpen(driver))
            return driver;
        else if (driver instanceof SafariDriver && (((SafariDriver) driver).getSessionId() != null) && checkIfBrowserSessionIsOpen(driver))
            return driver;
        else if (driver instanceof RemoteWebDriver && (((RemoteWebDriver) driver).getSessionId() != null) && checkIfBrowserSessionIsOpen(driver)) {
            return driver;
        }
        return null;
    }

    private static boolean checkIfBrowserSessionIsOpen(WebDriver sdriver) {
        try {
            sdriver.getWindowHandle();
            return true;
        } catch (NoSuchSessionException nse) {
            return false;
        }
    }

    /*
     * Returns current driver instance
     *
     * @return WebDriver
     */
    public static WebDriver getDefaultDriver() {


        String platform = System.getProperty(PLATFORM, DESKTOP);
        String timeOut = (I9RescueDriverUtil.getConfigMap().get(DEFAULT_WAIT_TIME) != null ? I9RescueDriverUtil.getConfigMap().get(DEFAULT_WAIT_TIME).toString() : "30");

        //check current driver instance
        driver = getDriverInstance();

        if (driver == null) {
            switch (platform.toLowerCase()) {
                case BROWSERSTACK:
                    driver = browserStackDriver();
                    break;
                case SAUCELAB:
                    log.error("SACUELAB is still not avaialble. Please select some other platform for execution.");
                    System.exit(0);
                    driver = saucelabDriver();
                    break;
                case DESKTOP:
                    driver = chooseDriver();
                    break;
                default:
                    log.info("\nException : Invalid platform " + platform);
                    System.exit(0);
            }
            driver.manage().timeouts().setScriptTimeout(35, TimeUnit.SECONDS);
            driver.manage().timeouts().pageLoadTimeout(Integer.parseInt(timeOut), TimeUnit.SECONDS);
            driver.manage().window().maximize();
        }
       // log.info("Default driver name  "+ driver);
        return driver;
    }

    /*
     * Returns saucelab remote driver instance by reading saucelab configuration
     * from platformConfigs/saucelab.properties
     *
     *
     * @return RemoteWebDriver
     */
    private static WebDriver saucelabDriver() {
        URL remoteDriverURL = null;
        RemoteWebDriver remoteDriver = null;
        DesiredCapabilities oCap = (DesiredCapabilities) getDefaultOptions(SAUCELAB);
        try {
            HashMap<String, String> sauceLabsConfigs = (HashMap) configMap.get("sauceLabs.configurations");

            //Set Proxy if Exists
            if (sauceLabsConfigs.containsKey(PROYX_HOST) && sauceLabsConfigs.get(PROYX_HOST) != null) {
                System.setProperty("java.net.useSystemProxies", "true");
                System.setProperty(HTTPS_PROXY_HOST, sauceLabsConfigs.get(PROYX_HOST));
                System.setProperty(HTTPS_PROXY_PORT, String.valueOf(sauceLabsConfigs.get(PROYX_PORT)));
            }
            String url = sauceLabsConfigs.get("protocol") + "://" + sauceLabsConfigs.get("username") + ":"
                    + sauceLabsConfigs.get(ACCESS_KEY) + sauceLabsConfigs.get("url");
            log.info("Initializing  webdriver in " + url);
            remoteDriverURL = new URL(url);
            remoteDriver = new RemoteWebDriver(remoteDriverURL, oCap);
        } catch (Exception e) {
            log.info("\nException Occured :\n");
            log.info(e.getMessage());
            System.exit(0);
        }
        return remoteDriver;
    }

    /*
     * Returns browserStack remote driver instance by reading browserStack
     * configuration from platformConfigs/browserstack.properties
     *
     *
     * @return RemoteWebDriver
     */
    private static WebDriver browserStackDriver() {
        URL remoteDriverURL = null;
        DesiredCapabilities oCap = (DesiredCapabilities) getDefaultOptions(BROWSERSTACK);
        try {
            HashMap<String, String> browserStackConfigs = (HashMap) configMap.get(BROWSERSTACK_CONFIGS);

            //Set Proxy if Exists
            if (browserStackConfigs.containsKey(PROYX_HOST) && browserStackConfigs.get(PROYX_HOST) != null) {
                System.setProperty("java.net.useSystemProxies", "true");
                System.setProperty(HTTPS_PROXY_HOST, browserStackConfigs.get(PROYX_HOST));
                System.setProperty(HTTPS_PROXY_PORT, String.valueOf(browserStackConfigs.get(PROYX_PORT)));
                System.setProperty(HTTPS_PROXY_USERNAME, browserStackConfigs.get("proxy.userName"));
                System.setProperty("https.proxyPassword", String.valueOf(browserStackConfigs.get("proxy.password")));
                oCap.setCapability("browserstack.local", "true");
            }

            String url = browserStackConfigs.get("protocol") + "://" + browserStackConfigs.get("username") + ":"
                    + browserStackConfigs.get(ACCESS_KEY) + browserStackConfigs.get("url");
            log.info("Initializing  webdriver in " + url);
            remoteDriverURL = new URL(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new RemoteWebDriver(remoteDriverURL, oCap);
    }



    public static Map<String, String> getDBCredentials() throws FileNotFoundException {

        String env = "dev";
        InputStream input = new FileInputStream(
                currentPath + "/src/main/java/com/equifax/ews/appConfigs/" + env + PROPERTIES);
        try {
            prop.load(input);
            input.close();
        } catch (FileNotFoundException e) {
            log.info(e.toString());
        } catch (IOException e) {
            log.info("exception", e);
        }

        String user = "";
        String pwd = "";
        String dbConnectionString = "";
        user = prop.getProperty("dbuser");
        pwd = prop.getProperty("dbpwd");
        dbConnectionString = prop.getProperty("dbconnectionstring");

        Map<String, String> dbCredentials = new HashMap<>();
        dbCredentials.put("user", user);
        dbCredentials.put("pwd", pwd);
        dbCredentials.put("dbconnectionstring", dbConnectionString);
        return dbCredentials;
    }

    /**
     * By default to web driver will be firefox
     * <p>
     * Override it by passing -DbrowserName=Chrome to the command line arguments
     *
     * @return webdriver
     */
    private static WebDriver chooseDriver() {

       // String browserName = (System.getProperty(BROWSERNAME) != null ? System.getProperty(BROWSERNAME) : getConfigData().get("I9Browser"));

        String browserName = (System.getProperty(BROWSERNAME) != null ? System.getProperty(BROWSERNAME) : prop.getProperty("DEFAULT_BROWSER"));




        //Add driver to path
        getBrowserDriver(browserName);
        //getBrowserDriverNew(browserName);
        switch (browserName.toLowerCase()) {
            case SAFARI:
                try {
                    SafariOptions sop = (SafariOptions) getDefaultOptions(browserName);
                    driver = new SafariDriver(sop);
                } catch (Exception e) {
                    log.info("Exception caught : " +e.getMessage());

                    System.exit(0);
                }
                return driver;
            case EDGE:
                try {
                    EdgeOptions eop = (EdgeOptions) getDefaultOptions(browserName);
                    driver = new EdgeDriver(eop);
                } catch (Exception e) {
                    log.info("Exception caught : " +e.getMessage());
                    System.exit(0);
                }
                return driver;
            case CHROME:
                ChromeOptions cop = (ChromeOptions) getDefaultOptions(browserName);
                cop.addArguments("ignore-certificate-errors");

                try {
                    driver = new ChromeDriver(cop);
                    ErrorHandler handler = new ErrorHandler();
                    handler.setIncludeServerErrors(false);
                } catch (Exception e) {
                    log.info("Exception caught : " +e.getMessage());
                    System.exit(0);
                }
                return driver;
            case IE:
                System.setProperty("webdriver.ie.driver", driverRelativePath + "IEDriverServer.exe");
                InternetExplorerOptions ieoptions = new InternetExplorerOptions();
                ieoptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
                ieoptions.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);

                try {
                    driver = new InternetExplorerDriver(ieoptions);

                } catch (Exception e) {
                    log.info("Exception caught : " +e.getMessage());
                    System.exit(0);
                }
                return driver;
            default:
                FirefoxOptions options = (FirefoxOptions) getDefaultOptions(browserName);
                try {
                    driver = new FirefoxDriver(options);
                } catch (Exception e) {
                    log.info("Exception caught : " +e.getMessage());
                    System.exit(0);
                }
                return driver;
        }
    }

    public static WebElement waitAndGetElementByCssSelector(WebDriver driver, String selector, int seconds) {
        By selection = By.cssSelector(selector);
        return (new WebDriverWait(driver, seconds)).until( // ensure element is
                // visible!
                ExpectedConditions.visibilityOfElementLocated(selection));
    }

    /*
     * If a driver is placed under resources/drivers folder, then it will be used to initialize WebDriver. Else driver has to be added in PATH variable
     *
     * @params browserName String
     */
    private static void getBrowserDriver(String browserName) {
        File file;

        log.info("Browser Name : "+ browserName);
        switch (browserName) {
            case FIREFOX:
                file = new File("src/test/resources/drivers/geckodriver.exe");
                if (file.exists())
                    System.setProperty("webdriver.gecko.driver", file.getAbsolutePath());

                break;
            case CHROME:
                String driverPath = format(PATH, getOSExecutableFileExtension());
                log.info("Driver path is  " + driverPath);
                file = new File(driverPath);
                //file = new File("src/test/resources/drivers/chromedriver.exe");
                if (file.exists())
                   System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
                //System.setProperty("webdriver.chrome.driver", driverPath);

                break;
            case IE:
                file = new File("src/test/resources/drivers/IEDriverServer.exe");
                if (file.exists())
                    System.setProperty("webdriver.ie.driver", file.getAbsolutePath());

                break;
            case EDGE:
                file = new File("src/test/resources/drivers/msedgedriver.exe");
                if (file.exists())
                    System.setProperty("webdriver.edge.driver", file.getAbsolutePath());

                break;
            default:
                break;
        }


    }


    private static String getOSExecutableFileExtension() {
        String extension= StringUtils.EMPTY;
        if (System.getProperty("os.name").startsWith("Windows")) {
            extension = ".exe";
        }
        else {
            log.info("It is linux machine ");
        }
        return extension;
    }

    public static Map<String, String> setConfigData() throws FileNotFoundException {
        configData = new HashMap<String, String>();
        InputStream input = new FileInputStream(
                currentPath + "/src/main/java/com/equifax/ews/appConfigs/config" + PROPERTIES);
        try {
            prop.load(input);
            input.close();
        } catch (FileNotFoundException e) {
            log.info(e.toString());
        } catch (IOException e) {
            log.info("exception", e);
        }
        configData.put("I9Environment",prop.getProperty("Environment"));
        configData.put("I9Browser",prop.getProperty("Browser"));
        return configData;
    }

    public static String getInputFromUser(String filePath, String inputValue) throws IOException {
        Scanner sc = new Scanner(new File(filePath));
        //instantiating the StringBuffer class
        StringBuffer buffer = new StringBuffer();
        //Reading lines of the file and appending them to StringBuffer
        while (sc.hasNextLine()) {
            buffer.append(sc.nextLine()+System.lineSeparator());
        }
        String fileContents = buffer.toString();
//        System.out.println("Contents of the file: "+fileContents);
        //closing the Scanner object
        sc.close();
        JFrame frame = new JFrame();
        frame.setAlwaysOnTop(true);
        String inputData= JOptionPane.showInputDialog(frame,"Enter the "+ inputValue + ": ");
//        String inputData = String.format("%07d", input);
//        System.out.println("inputData=============:"+inputData);
//        String blockId = Base64.getUrlEncoder().encodeToString(fixedLengthBlockNumber.getBytes("utf-8"));
        // Encode into Base64 format
        String inputEncoded
                = Base64.getEncoder()
                .encodeToString(inputData.getBytes("utf-8"));
        System.out.println("Out=============="+inputEncoded);
        // print encoded String
        System.out.println("Encoded String:\n"
                + inputEncoded);

        String oldLine = inputValue+"=";
        String newLine = oldLine+""+inputEncoded+"000";
        //Replacing the old line with new line
        fileContents = fileContents.replaceAll(oldLine, newLine);
        //instantiating the FileWriter class
        FileWriter writer = new FileWriter(filePath);
        System.out.println("");
        System.out.println("new data: "+fileContents);
        writer.append(fileContents);
        writer.flush();

        String inputEncodedValue =  inputEncoded.replace("000", "");
        // decode into String from encoded format
        byte[] actualByte = Base64.getDecoder()
                .decode(inputEncodedValue);

        String actualString = new String(actualByte);

        // print actual String
//        System.out.println("actual String======\n"
//                + actualString);
        return actualString;

    }

    public static String getDecodedInputFromUser(String inputValue) throws IOException {
        // decode into String from encoded format
        String inputEncodedValue =  inputValue.replace("000", "");
        byte[] actualByte = Base64.getDecoder()
                .decode(inputEncodedValue);

        String actualString = new String(actualByte);

        // print actual String
        System.out.println("actual String:\n"
                + actualString);
//        scn.close();
        return actualString;
    }



    private static void getBrowserDriverNew(String browserName) {

        switch (browserName) {
            case FIREFOX:
                WebDriverManager.firefoxdriver().setup();
                break;
            case CHROME:
         log.info("starting chrome using webdrivermanager");
               WebDriverManager.chromedriver().arch64().setup();
                log.info("started chrome using webdrivermanager");
               // WebDriverManager.getInstance(CHROME).setup();
              //  WebDriverManager.chromedriver().useMirror().setup();
              //  WebDriverManager.chromedriver().proxy("server:port").setup();

                //WebDriverManager.getInstance(DriverManagerType.valueOf(CHROME)).setup();
                //WebDriverManager.getInstance(CHROME).setup();
         /*       WebDriverManager.chromedriver()
                    .version("2.40")
                    .arch32()
                    .proxy("myproxyhostname:80")
                    .proxyUser("myusername")
                    .proxyPass("myawesomePassword")
                    .setup();*/
                break;
            case IE:
                WebDriverManager.iedriver().setup();
                break;
            case EDGE:
                WebDriverManager.edgedriver().setup();
                break;
            default:
                break;
        }


    }




}

