package com.equifax.ews.I9RescueServiceUtilities;



import com.equifax.ews.env.I9RescueDriverUtil;
import com.equifax.ews.pageObjects.AuditSummaryPage;
import com.equifax.ews.pageObjects.ConvertSummaryPage;
import com.equifax.ews.utilities.BaseTest;
import com.equifax.ews.utilities.FolderFileManagement;
import com.equifax.ews.utilities.WebAccesibility;
import io.cucumber.datatable.DataTable;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import static com.equifax.ews.utilities.BaseTest.progressObj;
import static org.openqa.selenium.By.cssSelector;
import static org.openqa.selenium.By.*;

@Slf4j
public class RescueCommon implements BaseTest {
    AuditSummaryPage objAuditSummaryPage= new AuditSummaryPage();
    ConvertSummaryPage objConvertSummaryPage= new ConvertSummaryPage();
    private WebDriver driver;
    FolderFileManagement folderObj;
    boolean webTest;

    public RescueCommon() {
        driver = I9RescueDriverUtil.getDefaultDriver();
        PageFactory.initElements(driver, this);
        folderObj = new FolderFileManagement();
        if (I9RescueDriverUtil.ACCESSBILITYCHECK == "true")
            webTest = new WebAccesibility().webAccess(driver, "Convert Summary-page");
    }

    public void enterParameterizedDataInFields(DataTable testData) {
        List<List<String>> dataTableRows = testData.asLists(String.class);
        int tableRows = dataTableRows.size();
        String[] arrOfKeys = new String[tableRows];
        String[] arrOfValues = new String[tableRows];
        try {
            for (int itr = 0; itr < tableRows; itr++) {
                arrOfKeys[itr] = dataTableRows.get(itr).get(0);
                arrOfValues[itr] = dataTableRows.get(itr).get(1);
                    WebElement testerObj = (WebElement) getTheWebElement(arrOfKeys[itr]);
                    progressObj.waitForElementToDisplay(testerObj, "5000");
                    testerObj.clear();
                    testerObj.sendKeys(arrOfValues[itr]);
                    log.info("entered value on the element: " + arrOfKeys[itr]);
            }
        }catch(Exception e){
            log.info("Exception in entering data to fields");
        }
    }
    public boolean correctionWithParameterizedData(DataTable testData) {
        boolean boolisAllCorrectionSuccess = true;
        List<List<String>> dataTableRows = testData.asLists(String.class);
        int tableRows = dataTableRows.size();
        String[] arrOfKeys = new String[tableRows];
        String[] arrOfValues = new String[tableRows];
        String[] arrCorrectionType = new String[tableRows];
        String[] arrEmployerType = new String[tableRows];
        try {
            for (int itr = 0; itr < tableRows; itr++) {
                arrOfKeys[itr] = dataTableRows.get(itr).get(0);
                arrOfValues[itr] = dataTableRows.get(itr).get(1);
                arrCorrectionType[itr] = dataTableRows.get(itr).get(2);
                arrEmployerType[itr]= dataTableRows.get(itr).get(3);
                correction(arrOfKeys[itr],arrOfValues[itr],arrCorrectionType[itr],arrEmployerType[itr]);
                boolean isDataCorrected= verifySuccessMessageDisplayedAfterDataCorrection();
                if(isDataCorrected){
                    log.error("Correction for the field "+arrOfKeys[itr]+ " is successful");
                }else {
                    boolisAllCorrectionSuccess = false;
                    log.error("Correction for the field "+arrOfKeys[itr]+ " is NOT successful");
                }
            }
            }catch(Exception e){
            log.info("Exception in correction");
            boolisAllCorrectionSuccess = false;
        }
        return boolisAllCorrectionSuccess;
    }

    public boolean validateDataInFields(DataTable testData) {
        boolean validateAllFields = true;
        String fieldValue = "";
        List<List<String>> dataTableRows = testData.asLists(String.class);
        int tableRows = dataTableRows.size();
        String[] arrOfKeys = new String[tableRows];
        String[] arrOfValues = new String[tableRows];
        try {
            for (int itr = 0; itr < tableRows; itr++) {
                arrOfKeys[itr] = dataTableRows.get(itr).get(0);
                arrOfValues[itr] = dataTableRows.get(itr).get(1);
                progressObj.waitForJavascriptToLoad(20000, 4000);
                WebElement testerObj = (WebElement) getTheWebElement(arrOfKeys[itr]);
                progressObj.waitForElementToDisplay(testerObj, "10000");
                fieldValue =testerObj.getAttribute("value");
                if(!(arrOfValues[itr].equalsIgnoreCase(fieldValue))){
                    validateAllFields = false;
                    log.error("The actual value '"+fieldValue+"' in field "+arrOfKeys[itr]+ " is  not match with the expected :"+arrOfValues[itr]);
                }else {
                    log.info("The actual value '"+fieldValue+"' in field "+arrOfKeys[itr]+ " is  matching with the expected :"+arrOfValues[itr]);
                }

            }
        }catch(Exception e){
            log.info("Exception in fetching data from fields");
        }
        return validateAllFields;
    }

    public Object getTheWebElement(String fieldLabel) {
            try{
                switch (fieldLabel) {
                    case "NewSec2EmployeeInfoLastName":
                        return objAuditSummaryPage.getNewSec2EmployeeInfoLastName();
                    case "NewSec2EmployeeInfoFirstName":
                        return objAuditSummaryPage.getNewSec2EmployeeInfoFirstName();
                    case "NewSec2EmployeeInfoHireDate":
                        return objAuditSummaryPage.getNewSec2EmployeeInfoHireDate();
                    case "USPassportIssuingAuthority":
                        return objAuditSummaryPage.getUSPassportIssuingAuthority();
                    case "USPassportDocumentNumber":
                        return objAuditSummaryPage.getUSPassportDocumentNumber();
                    case "USPassportExpiryDate":
                        return objAuditSummaryPage.getUSPassportExpiryDate();
                    case "CapturedDataSection2EmployeeFirstName":
                        return objAuditSummaryPage.getCapturedDataSection2EmployeeFirstName();
                    case "CapturedDataSection2EmployeeLastName":
                        return objAuditSummaryPage.getCapturedDataSection2EmployeeLastName();
                    case "CapturedDataSection2EmployeeHireDate":
                        return objAuditSummaryPage.getCapturedDataSection2EmployeeHireDate();
                    case "CapturedDataSection2ListADoc1IssueAuthority":
                        return objAuditSummaryPage.getCapturedDataSection2ListADoc1IssueAuthority();
                    case "CapturedDataSection2ListADoc1DocNumber":
                        return objAuditSummaryPage.getCapturedDataSection2ListADoc1DocNumber();
                    case "CapturedDataSection2ListADoc1Expiry":
                        return objAuditSummaryPage.getCapturedDataSection2ListADoc1Expiry();
                    case "CapturedDataSection2ListADoc1Title":
                        return objAuditSummaryPage.getCapturedDataSection2ListADoc1Title();
                    case "CapturedDataSection1FirstName":
                        return objAuditSummaryPage.getCapturedDataSection1FirstName();
                    case "CapturedDataSection3EmployeeRehireDate":
                        return objAuditSummaryPage.getCapturedDataSection3EmployeeRehireDate();
                    case "CapturedDataSection3DocTitle":
                        return objAuditSummaryPage.getCapturedDataSection3DocTitle();
                    case "NewSec3EmployeeInfoLastName":
                        return objAuditSummaryPage.getNewSec3EmployeeInfoLastName();
                    case "NewSec3EmployeeInfoFirstName":
                        return objAuditSummaryPage.getNewSec3EmployeeInfoFirstName();
                    case "NewSec3EmployeeInfoHireDate":
                        return objAuditSummaryPage.getNewSec3EmployeeInfoHireDate();
                    case "NewSec3NameChangeFirstName":
                        return objAuditSummaryPage.getNewSec3NameChangeFirstName();
                    case "NewSec3NameChangeLastName":
                        return objAuditSummaryPage.getNewSec3NameChangeLastName();
                    case "NewSec3NameChangeMiddleInitial":
                        return objAuditSummaryPage.getNewSec3NameChangeMiddleInitial();
                    case "NewSec3RehireDate":
                        return objAuditSummaryPage.getNewSec3RehireDate();
                    case "CapturedDataSection3EmployeeFirstName":
                        return objAuditSummaryPage.getCapturedDataSection3EmployeeFirstName();
                    case "CapturedDataSection3EmployeeLastName":
                        return objAuditSummaryPage.getCapturedDataSection3EmployeeLastName();
                    case "CapturedDataSection3EmployeeMiddleInitial":
                        return objAuditSummaryPage.getCapturedDataSection3EmployeeMiddleInitial();

                    case "CapturedDataConverterSection1FirstName":
                        return objConvertSummaryPage.getCapturedDataSection1FirstName();
                    case "CapturedDataConverterSection2EmployeeFirstName":
                        return objConvertSummaryPage.getCapturedDataSection2EmployeeFirstName();
                    case "CapturedDataConverterSection3EmployeeRehireDate":
                        return objConvertSummaryPage.getCapturedDataSection3EmployeeRehireDate();
                    case "DataCorrectionType":
                        return objConvertSummaryPage.getDataCorrectionType();



                    default:
                        log.error("The element : " + fieldLabel + " is not recorded in page object class");
                        return null;
                }
        }
        catch(Exception e)
        {
            log.error("Unable to locate the element : "+fieldLabel);
            return null;
        }
    }

    public void correction(String fieldName, String fieldValue, String correctionType,String employerType) {
        WebElement element = null;
        try {
            WebElement testerObj = (WebElement) getTheWebElement(fieldName);
            progressObj.waitForElementToDisplay(testerObj, "5000");
            progressObj.waitForJavascriptToLoad(20000, 2000);
            testerObj.clear();
            log.info("Entering value in field");
            testerObj.sendKeys(fieldValue);
            log.info("Clicking tab");
            testerObj.sendKeys(Keys.TAB);
            try {
                //WebElement popUp = driver.findElement(cssSelector("#auditDataCaptureModalTitle"));
//                element = driver.findElement(By.xpath("//select[@id='reasonForEditing']"));
//                Select errorOption = new Select(element);
//                WebElement dropDownElement = driver.findElement(By.xpath("//select[@id='reasonForEditing']"));
//                progressObj.waitForElementToClickable(dropDownElement, "10");
//                dropDownElement.click();
//                errorOption.selectByVisibleText(correctionType);
//                progressObj.waitForJavascriptToLoad(4000, 2000);

                progressObj.waitForPageLoad(driver);
                Select errorOption = new Select(driver.findElement(cssSelector("#reasonForEditing")));
                System.out.print(errorOption + correctionType);
                WebElement dropDownElement = driver.findElement(cssSelector("#reasonForEditing"));
                progressObj.waitForElementToClickable(dropDownElement, "10");
                dropDownElement.click();
                errorOption.selectByVisibleText(correctionType);
                progressObj.waitForJavascriptToLoad(4000, 2000);

                if(employerType.equalsIgnoreCase("Converter")) {
                    progressObj.waitForElementToClickable(driver.findElement(By.xpath("//button[@class='btn btn-primary'][text()='Send']")), "10");
                    driver.findElement(By.xpath("//button[@class='btn btn-primary'][text()='Send']")).click();
                    log.info("Selected Data capture issue and send");
                }
                else{
                    progressObj.waitForElementToClickable(driver.findElement(By.xpath("//button[@class='btn btn-primary'][text()='Save']")), "10");
                    driver.findElement(By.xpath("//button[@class='btn btn-primary'][text()='Save']")).click();
                    log.info("Selected Data capture issue and save");
                }
            } catch (java.util.NoSuchElementException noSuchElementException) {
                log.error("No pop up found", noSuchElementException);
            } catch(Exception e){
                e.printStackTrace();
            }
        } catch (java.util.NoSuchElementException noSuchElementException) {
            log.error("No element found for" + fieldName + "field");
        } catch (StaleElementReferenceException staleElementReferenceException) {
            log.error("Element is not attached to the page document " + staleElementReferenceException);
        }
    }

    public boolean verifySuccessMessageDisplayedAfterDataCorrection(){
        progressObj.waitForPageLoad(driver);
        progressObj.waitForJavascriptToLoad(10000, 1000);
        boolean successMessagePopupPresent = false;
        try {
            //progressObj.waitForElementToDisplay(driver.findElement(By.xpath("//div[contains(@class,'col-xs-11 col-sm-4 alert alert-success')]//span[contains(text(), 'Data Captured Successfully')]")), "30");
            WebDriverWait wait = new WebDriverWait(driver, 20);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'col-xs-11 col-sm-4 alert alert-success')]//span[contains(text(), 'Data Captured Successfully')]")));

                    successMessagePopupPresent = true;
            log.info("Success Message is displayed after data capture");
        }
        catch (java.util.NoSuchElementException noSuchElementException) {
            log.error("No success message displayed after data capture");
            successMessagePopupPresent = false;
        } catch (Exception e){
            log.error("No success message displayed after data capture");
            successMessagePopupPresent = false;
        }
        return successMessagePopupPresent;

    }
    public int getCount(WebElement countElement){
        int count;
        String countInString = countElement.getText();
        count = Integer.parseInt(countInString);
        System.out.println(count);
        return count;
    }
}
