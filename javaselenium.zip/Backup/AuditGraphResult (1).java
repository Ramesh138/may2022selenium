package com.equifax.ews.I9RescueServiceUtilities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.Date;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AuditGraphResult {

    private String employerIdentifier;
    private String locationIdentifier;
    @JsonInclude(Include.NON_NULL)
    private int year;
    @JsonInclude(Include.NON_NULL)
    private Date month;
    @JsonInclude(Include.NON_NULL)
    private Date weekStart;
    private int historicalI9sUploaded;
    private int noOfI9sWithIssues;
    private int totalNoOfIssues;
    private int totalI9sResolved;
}
