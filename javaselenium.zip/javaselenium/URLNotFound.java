package com.equifax.ews.utilities;

public class URLNotFound extends Exception {
    /**
     * Added serializable varibale to remove warning
     */
    private static final long serialVersionUID = 1L;
    public String message = null;

    public URLNotFound() {
        super();
    }

    public URLNotFound(String message) {
        super(message);
        this.message = message;
    }

}
