package com.equifax.ews.utilities;

import org.openqa.selenium.By;

public class SelectElementByType {

    /**
     * Method to select element 'by' type
     *
     * @param type       : String : 'By' type
     * @param accessName : String : Locator value
     * @return By
     */
    public By getelementbytype(String type, String accessName) {

        switch (type) {
            case "id":
                return By.id(accessName);
            case "name":
                return By.name(accessName);
            case "class":
                return By.className(accessName);
            case "xpath":
                return By.xpath(accessName);
            case "css":
                return By.cssSelector(accessName);
            case "linkText":
                return By.linkText(accessName);
            case "partialLinkText":
                return By.partialLinkText(accessName);
            case "tagName":
                return By.tagName(accessName);
            default:
                return null;

        }

        /**
         * Method to identify and return WebElement
         *
         * @param locatorType : String : Locator type
         * @param locatorInfo : String : Locator value
         * @return WebElement
         */


    }
}