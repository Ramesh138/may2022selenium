package com.equifax.ews.utilities;

import com.equifax.ews.logging.LogFactory;
import com.equifax.ews.logging.Logger;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.Arrays;

@Slf4j
public class MiscMethods {
 //   private static Logger logger = LogFactory.getLogger(MiscMethods.class);

    public boolean validLocatorType(String type) {
        return Arrays.asList("id", "class", "css", "name", "xpath", "linkText", "partialLinkText", "tagName").contains(type);
    }

    /**
     * Method to verify locator type
     *
     * @param type : String : Locator type (id, name, class, xpath, css)
     */
    public void validateLocator(String type) {
        if (!validLocatorType(type))
            log.info("Invalid locator type - " + type);
    }

    // method to validate dropdown selector
    public boolean validOptionBy(String optionBy) {
        return Arrays.asList("text", "value", "index").contains(optionBy);
    }

    /**
     * Method to verify dropdown selector (text, value or index)
     *
     * @param optionBy : String : Locator type (text, value, index)
     */
    public void validateOptionBy(String optionBy) {
        if (!validOptionBy(optionBy))
            log.info("Invalid option by - " + optionBy);
    }

    public void dropDownSelectByVisibletext(WebElement element, String value){
        Select dropdown = new Select(element);
        dropdown.selectByVisibleText(value);
    }
}
