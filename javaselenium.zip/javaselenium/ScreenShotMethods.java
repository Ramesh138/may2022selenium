package com.equifax.ews.utilities;

import com.equifax.ews.env.I9RescueDriverUtil;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class ScreenShotMethods implements BaseTest {
    protected WebDriver driver = I9RescueDriverUtil.getDefaultDriver();

    //Method to take screen shot and save in ./screenShots folder
    public void takeScreenShot() throws IOException {
        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        DateFormat dateFormat = new SimpleDateFormat("MMMM-dd-yyyy-z_HH-mm-ss", Locale.ENGLISH);
        Calendar cal = Calendar.getInstance();
        FileUtils.copyFile(scrFile, new File("screenShots/", dateFormat.format(cal.getTime()) + ".png"));
    }
}
