package com.equifax.ews.utilities;

import com.equifax.ews.env.I9RescueDriverUtil;
import com.equifax.ews.logging.LogFactory;
import com.equifax.ews.logging.Logger;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnsupportedCommandException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
@Slf4j
public class ClickElementsMethods extends SelectElementByType implements BaseTest {
 //   private static Logger logger = LogFactory.getLogger(ClickElementsMethods.class);
    private WebElement element = null;

    /**
     * Method to click on an element
     *
     * @param accessType : String : Locator type (id, name, class, xpath, css)
     * @param accessName : String : Locator value
     */
    public void click(String accessType, String accessName) {
        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
        WebDriverWait wait = new WebDriverWait(driver, 15);
        element = wait.until(ExpectedConditions.presenceOfElementLocated(getelementbytype(accessType, accessName)));

        element.click();
    }

    /**
     * Method to forcefully click on an element
     *
     * @param accessType : String : Locator type (id, name, class, xpath, css)
     * @param accessName : String : Locator value
     */
    public void clickForcefully(String accessType, String accessName) {
        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
        WebDriverWait wait = new WebDriverWait(driver, 30);
        element = wait.until(ExpectedConditions.presenceOfElementLocated(getelementbytype(accessType, accessName)));
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", element);
    }

    /**
     * Method to Double click on an element
     *
     * @param accessType  : String : Locator type (id, name, class, xpath, css)
     * @param accessValue : String : Locator value
     */
    public void doubleClick(String accessType, String accessValue) {
        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
        WebDriverWait wait = new WebDriverWait(driver, 30);
        element = wait.until(ExpectedConditions.presenceOfElementLocated(getelementbytype(accessType, accessValue)));

        Actions action = new Actions(driver);
        action.moveToElement(element).doubleClick().perform();
    }

    public void waitForPageLoad(WebDriver driver) {
        ExpectedCondition<Boolean> pageLoadCondition = driver1 -> {
            try {
                return ((JavascriptExecutor) driver1).executeScript("return document.readyState").equals("complete");
            } catch (UnsupportedCommandException e) {
                return false;
            }
        };
        WebDriverWait ninetySecond = new WebDriverWait(driver, 90);
        ninetySecond.until(pageLoadCondition);
    }

    public void waitForJavascriptToLoad(int maxWaitMillis, int pollDelimiter) {

        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();

        waitForPageLoad(driver);
        double startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() < startTime + maxWaitMillis) {
            try {
                String prevState = driver.getPageSource();
                Thread.sleep(pollDelimiter);
                if (prevState.equals(driver.getPageSource())) {
                    return;
                }
            } catch (Exception e) {
                log.error("Exception caught", e);
            }
        }
    }

}