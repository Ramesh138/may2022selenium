package com.equifax.ews.utilities;

import com.equifax.ews.logging.LogFactory;
import com.equifax.ews.logging.Logger;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

/**
 * This class contains common utility functions available for the project.
 */

class Commons {

    public static final Random rand = new Random();
    private static Logger logger = LogFactory.getLogger(Commons.class);

    private Commons() {
        throw new IllegalStateException("Utility class");
    }

    public static synchronized long getCurrentTimeStamp() {
        return System.nanoTime();
    }

    public static Date getTime() {
        Calendar calendar = Calendar.getInstance();
        return calendar.getTime();
    }

    public static String getDateTime(String dateTimeFormat) {
        DateFormat dateFormat = new SimpleDateFormat(dateTimeFormat);
        Date date = new Date();
        return dateFormat.format(date);
    }

    public static void generateFile(String filePath) {
        File file = new File(filePath);
        file.getParentFile().mkdirs();
        try {
            FileWriter writer = new FileWriter(file);
            writer.close();
        } catch (IOException e) {
            logger.printStackTrace(e);
        }
    }

    public static String getRelativePath(String basePath, String otherPath) {
        Path basePathObj = Paths.get(basePath);
        Path otherPathObj = Paths.get(otherPath);
        Path relativePath = basePathObj.relativize(otherPathObj);
        return relativePath.toString();
    }

    public static String getRandomNumber(int length) {
        StringBuilder builder = new StringBuilder();
        int i = 0;
        while (i < length) {
            builder.append(getRandomInt());
            i++;
        }
        return builder.toString();
    }

    private static int getRandomInt() {
        return rand.nextInt(9);

    }

    /**
     * Generate Edit string by appending Edit or by removing Edit from the string.
     */
    public static String generateEditInput(String input) {
        if (input.contains("Edit")) {
            return input.replace("Edit", "");
        } else {
            return input + "Edit";
        }
    }

    /**
     * Generates random number with in given range.
     */
    public static int getRandomNumber(int min, int max) {
        return min + rand.nextInt(max);
    }

}
