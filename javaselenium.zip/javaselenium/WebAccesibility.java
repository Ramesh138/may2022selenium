package com.equifax.ews.utilities;

import com.deque.axe.AXE;
import io.cucumber.java.bs.I;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import lombok.extern.slf4j.XSlf4j;
import org.apache.commons.exec.util.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

@Slf4j
public class WebAccesibility {

    public static final URL scriptUrl = I.class.getResource("/axe.min.js"); //path to the axe.min.js file
    public static String currentPath = System.getProperty("user.dir");
    public static String ACCESSBILITYFOLDERPATH = currentPath + "\\src\\test\\resources\\AccesibilityTest";
    public static String RESOURCEFOLDERPATH = currentPath + "\\src\\test\\resources";
    public static String ACCESSIBILITYPATH = null;
    public static List<String> PAGEURLS = new ArrayList<>();

    private boolean webAccessibilityTest(WebDriver driver, String title) {
        String PagePath;
        boolean accesibility;
        if (title == null) {
            PagePath = WebAccesibility.ACCESSIBILITYPATH + File.separator + driver.getTitle();
        } else {
            PagePath = WebAccesibility.ACCESSIBILITYPATH + File.separator + title;
        }

        log.info("WCAG scanning using AXE is started for :" + title);
        AXE.inject(driver, scriptUrl);
        JSONObject responseJSON = new AXE.Builder(driver, scriptUrl).analyze();
        JSONArray violations = responseJSON.getJSONArray("violations");
        if (violations.length() == 0) {

            accesibility=true;
            log.info("No violations found for the page: "+ title);
            AXE.writeResults(PagePath, responseJSON);

        } else {
            AXE.writeResults(PagePath, responseJSON);
            AXE.report(violations);
            log.info("AXE Violation Report for the page: " + title);
            log.info("--------------------------------------------");
            log.info(AXE.report(violations));
            accesibility=false;
        }

       return accesibility;
    }

    private void webAccessibilityFolderCheck() {
        FolderFileManagement folderobj = new FolderFileManagement();
        ACCESSIBILITYPATH = folderobj.createFolder(WebAccesibility.RESOURCEFOLDERPATH, "AccesibilityTest");
    }

    private boolean checkWebAccessibilityTestNeeded(String pageUrl) {

        boolean result = PAGEURLS.contains(pageUrl);
        if (!result) {
            int pageSize = PAGEURLS.size();
            PAGEURLS.add(pageSize, pageUrl);
        }
        return result;
    }

    public boolean webAccess(WebDriver driver, String title) {
        boolean accesibility=false;
        if (ACCESSIBILITYPATH == null) {
            this.webAccessibilityFolderCheck();
        }
        if (!this.checkWebAccessibilityTestNeeded(driver.getCurrentUrl())) {
            accesibility = this.webAccessibilityTest(driver, title);
        }
        return accesibility;
    }

    public boolean webAccessAlways(WebDriver driver, String title) {
        boolean accesibility;
        if (ACCESSIBILITYPATH == null) {
            this.webAccessibilityFolderCheck();
        }accesibility = this.webAccessibilityTest(driver, title);
        return accesibility;
    }

}
