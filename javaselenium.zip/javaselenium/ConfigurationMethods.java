package com.equifax.ews.utilities;

import com.equifax.ews.env.I9RescueDriverUtil;
import com.equifax.ews.logging.LogFactory;
import com.equifax.ews.logging.Logger;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

@Slf4j
public class ConfigurationMethods implements BaseTest {
  //  private static Logger logger = LogFactory.getLogger(ConfigurationMethods.class);
    protected WebDriver driver;

    public ConfigurationMethods() {
        driver = I9RescueDriverUtil.getDefaultDriver();
    }

    /**
     * Method to print desktop configuration
     */
    public void printDesktopConfiguration() {
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
        Calendar cal = Calendar.getInstance();
        log.info("Following are machine configurations: \n");
        log.info("Date (MM/DD/YYYY) and Time (HH:MM:SS) : " + dateFormat.format(cal.getTime()));
        Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
        log.info("Browser : " + cap.getBrowserName());
        log.info("Platform : " + cap.getPlatform());
    }
}
