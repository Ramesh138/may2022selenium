package com.equifax.ews.utilities;

import com.equifax.ews.env.I9RescueDriverUtil;
import com.equifax.ews.logging.LogFactory;
import com.equifax.ews.logging.Logger;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.UnsupportedCommandException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@Slf4j
public class ProgressMethods extends SelectElementByType implements BaseTest {
    /**
     * Method to wait
     *
     * @param time
     * : String : Time to wait
     * //@param method
     * : String : wait by sleep or implicit method
     * @throws NumberFormatException
     * @throws InterruptedException
     */

//    private static Logger logger = LogFactory.getLogger(ProgressMethods.class);


    public void wait(String time) throws InterruptedException {
        // sleep method takes parameter in milliseconds
        Thread.sleep((long) Integer.parseInt(time) * 1000);
    }

    /**
     * Method to Explicitly wait for element to be displayed
     *
     * @param accessType : String : Locator type (id, name, class, xpath, css)
     * @param accessName : String : Locator value
     * @param duration   : String : Time to wait for element to be displayed
     */
    public void waitForElementToDisplay(String accessType, String accessName, String duration) {
        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
        By byEle = getelementbytype(accessType, accessName);
        WebDriverWait wait = (new WebDriverWait(driver, Integer.parseInt(duration)));
        wait.until(ExpectedConditions.visibilityOfElementLocated(byEle));
    }

    public void waitForElementToDisplay(WebElement element, String duration) {
        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
        WebDriverWait wait = (new WebDriverWait(driver, Integer.parseInt(duration)));
        wait.until(ExpectedConditions.visibilityOf(element));
    }


    /**
     * Method to Explicitly wait for element to be enabled=click
     *
     * @param accessType : String : Locator type (id, name, class, xpath, css)
     * @param accessName : String : Locator value
     * @param duration   : String : Time to wait for element to be clickable
     */
    public void waitForElementToClick(String accessType, String accessName, String duration) {
        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
        By byEle = getelementbytype(accessType, accessName);
        WebDriverWait wait = (new WebDriverWait(driver, (long) Integer.parseInt(duration) * 1000));
       wait.until(ExpectedConditions.elementToBeClickable(byEle));

    }

    public void waitForElementToClick(WebElement element, String duration) {
        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
        WebDriverWait wait = (new WebDriverWait(driver, (long) Integer.parseInt(duration) * 1000));
        wait.until(ExpectedConditions.elementToBeClickable(element));

    }


    public void waitForPageLoad(WebDriver driver) {
        ExpectedCondition<Boolean> pageLoadCondition = driverApply -> {
            try {
                return ((JavascriptExecutor) driverApply).executeScript("return document.readyState").equals("complete");
            } catch (UnsupportedCommandException e) {
                return false;
            }
        };
        WebDriverWait ninetySecond = new WebDriverWait(driver, 90);
        ninetySecond.until(pageLoadCondition);
    }

    public void waitForJavascriptToLoad(int maxWaitMillis, int pollDelimiter) {
        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
        waitForPageLoad(driver);
        double startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() < startTime + maxWaitMillis) {
            try {
                String prevState = driver.getPageSource();
                Thread.sleep(pollDelimiter);
                if (prevState.equals(driver.getPageSource())) {
                    return;
                }
            } catch (Exception e) {
               // log.printStackTrace(e);
                log.error("Error : " + e);
            }
        }
    }

    public void waitForElementToClickable(String accessType, String accessName, String duration) {
        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
        By byEle = getelementbytype(accessType, accessName);
        WebDriverWait wait = (new WebDriverWait(driver, Integer.parseInt(duration)));
        wait.until(ExpectedConditions.elementToBeClickable(byEle));

    }

    public void waitForElementToClickable(WebElement element, String duration) {
        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
        WebDriverWait wait = (new WebDriverWait(driver, Integer.parseInt(duration)));
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }
    public void waitForInvisibilityOfElement(WebElement element, String duration) {
        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
        WebDriverWait wait = (new WebDriverWait(driver, Integer.parseInt(duration)));
        wait.until(ExpectedConditions.invisibilityOf(element));
    }

    public void waitForInvisibilityOfElement(By locatorKey, String duration) {
        WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
        WebDriverWait wait = (new WebDriverWait(driver, Integer.parseInt(duration)));
        wait.until(ExpectedConditions.invisibilityOfElementLocated(locatorKey));
    }

    public boolean isElementPresent(By locatorKey) {
        try {
            WebDriver driver = I9RescueDriverUtil.getDefaultDriver();
            driver.findElement(locatorKey);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }
}
