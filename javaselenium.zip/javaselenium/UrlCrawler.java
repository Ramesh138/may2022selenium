package com.equifax.ews.utilities;

import com.equifax.ews.env.I9RescueDriverUtil;
import com.equifax.ews.logging.LogFactory;
import com.equifax.ews.logging.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class UrlCrawler extends I9RescueDriverUtil {

    private static Logger logger = LogFactory.getLogger(UrlCrawler.class);
    static String currentPath = System.getProperty("user.dir");

    public void checkLinks()  {

        List<WebElement> links= driver.findElements(By.tagName("a"));
        links.addAll(driver.findElements(By.tagName("img")));
        FileWriter fostream = null;
        try {
            fostream = new FileWriter(new File(currentPath + File.separator + "testResult.txt"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        PrintWriter out = new PrintWriter(new BufferedWriter(fostream));

        out.println("#---------------------------------------------------------------------------------------------------------------------------------------------------------#"+"\n");

        for(int i=0;i<links.size();i++)
        {

            WebElement ele= links.get(i);

            String url=ele.getAttribute("href");

            verifyLinkActive(url,fostream, out);

        }
        out.close();
    }

    public static void verifyLinkActive(String linkUrl ,FileWriter fostream, PrintWriter out)
    {
        try
        {
            System.setProperty("https.proxyHost","172.22.240.68");
            System.setProperty("https.proxyPort","18717");

            URL url = new URL(linkUrl);

            HttpURLConnection httpURLConnect=(HttpURLConnection)url.openConnection();

            httpURLConnect.setConnectTimeout(4000);

            httpURLConnect.connect();

            httpURLConnect.getResponseCode();

            logger.info(linkUrl+" - "+httpURLConnect.getResponseMessage());
            try {
                out.println(linkUrl+" - "+httpURLConnect.getResponseMessage());
            } catch (Exception e) {

            }

        } catch (Exception e) {

        }
    }
    }





