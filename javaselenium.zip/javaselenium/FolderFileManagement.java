package com.equifax.ews.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import lombok.extern.slf4j.Slf4j;

/*
    This utility is used for folder creation, copy necessary files to the desired location, moving the zip files to archive-error location etc
 */
@Slf4j
public class FolderFileManagement{

      boolean  folderResult;

    public  String createFolder( String parentFolderPath, String folderName) {
        String fileName = parentFolderPath + File.separator + folderName;
        if ((!parentFolderPath.isEmpty()) || (!folderName.isEmpty())) {
            File createfile = new File(parentFolderPath, folderName);
            if (!createfile.exists()) {
                folderResult = createfile.mkdir();
                if (folderResult) {
                    log.info(folderName + "  :  created successfully");

                }

            } else {
                log.info(folderName + " folder is already present:");
            }

        } else {
            log.info(" Names supplied to create the folder is empty");
        }
        return fileName;
    }

    public String createFileIfNotExist(String fileName) {
        createFolder( WebAccesibility.RESOURCEFOLDERPATH, "AccesibilityTest");
        String fileNamePath=  WebAccesibility.ACCESSBILITYFOLDERPATH + File.separator + fileName;
        File file = new File(WebAccesibility.ACCESSBILITYFOLDERPATH, fileName);
        if (!file.exists()) {
            try {
                file.createNewFile();
                log.info("File is created!");
            } catch (IOException e) {
                e.printStackTrace();
                log.error("IOException while creating the file ");
            }
        } else {
            log.info("File already existed!");
        }
        return fileNamePath;
    }




    public void copyFile(String SourceFile, String DestinationFile){

        InputStream inStream;
        OutputStream outStream;
        try{
            File source =new File(SourceFile);
            File destination =new File(DestinationFile);
            inStream = new FileInputStream(source);
            outStream = new FileOutputStream(destination);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inStream.read(buffer)) > 0){
                outStream.write(buffer, 0, length);
            }
            inStream.close();
            outStream.close();
        }catch(IOException e){
            e.printStackTrace();
            log.error("IOException while copying the file" + SourceFile);
        }
    }


}




