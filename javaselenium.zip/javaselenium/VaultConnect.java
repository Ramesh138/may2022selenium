package com.equifax.ews.utilities;

import com.bettercloud.vault.Vault;
import com.bettercloud.vault.VaultConfig;
import com.bettercloud.vault.VaultException;
import com.equifax.ews.env.I9RescueDriverUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;

@Slf4j
public class VaultConnect {
    static String vaulttoken;
    static String vaulthost;
    public static String USERNAME;
    public static String PASSWORD;

   public static void setCredentials(){


       USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
           I9RescueDriverUtil.prop.getProperty("VAULT_USERNAMEKEY"));
       PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
           I9RescueDriverUtil.prop.getProperty("VAULT_PASSWORDKEY"));


   }
    public static void setCredentials(String userRole){

        if(userRole.equalsIgnoreCase("I9InspectAuditorAdmin")) {

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECTAUDITORADMIN_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECTAUDITORADMIN_PASS"));
         }
        else if (userRole.equalsIgnoreCase("I9InspectAuditorAgent")) {


            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECTAUDITORAGENT_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECTAUDITORAGENT_PASS"));

        }
        else if (userRole.equalsIgnoreCase("HrAdmin")) {


            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                I9RescueDriverUtil.prop.getProperty("VAULT_HRADMIN_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                I9RescueDriverUtil.prop.getProperty("VAULT_HRADMIN_PASS"));

        }
        else if (userRole.equalsIgnoreCase("HrAgent")) {


            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                I9RescueDriverUtil.prop.getProperty("VAULT_HRAGENT_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                I9RescueDriverUtil.prop.getProperty("VAULT_HRAGENT_PASS"));

        }
        else if (userRole.equalsIgnoreCase("ConvertHRAgent")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                I9RescueDriverUtil.prop.getProperty("VAULT_CONVERT_HRAGENT_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                I9RescueDriverUtil.prop.getProperty("VAULT_CONVERT_HRAGENT_PASS"));

        }
        else if (userRole.equalsIgnoreCase("ConvertHRAdmin")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                I9RescueDriverUtil.prop.getProperty("VAULT_CONVERTHRADMIN_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                I9RescueDriverUtil.prop.getProperty("VAULT_CONVERTHRADMIN_PASS"));

        }
        else if (userRole.equalsIgnoreCase("CSA_Agent")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_CSA_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_CSA_PASS"));

        }
        else if (userRole.equalsIgnoreCase("NonInspectHRAdmin")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9NONINSPECT_ADMIN_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9NONINSPECT_ADMIN_PASS"));

        }
        else if (userRole.equalsIgnoreCase("StarterAuditorHRAgent")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STARTER_AUDITOR_AGENT_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STARTER_AUDITOR_AGENT_PASS"));

        }
        else if (userRole.equalsIgnoreCase("StandardAuditorHRAgent")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STANDARD_AUDITOR_AGENT_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STANDARD_AUDITOR_AGENT_PASS"));

        }
        else if (userRole.equalsIgnoreCase("AdvancedAuditorHRAgent")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_ADVANCED_AUDITOR_AGENT_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_ADVANCED_AUDITOR_AGENT_PASS"));

        }
        else if (userRole.equalsIgnoreCase("StarterAuditorHRAdmin")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STARTER_AUDITOR_ADMIN_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STARTER_AUDITOR_ADMIN_PASS"));

        }
        else if (userRole.equalsIgnoreCase("StandardAuditorHRAdmin")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STANDARD_AUDITOR_ADMIN_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STANDARD_AUDITOR_ADMIN_PASS"));

        }
        else if (userRole.equalsIgnoreCase("AdvancedAuditorHRAdmin")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_ADVANCED_AUDITOR_ADMIN_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_ADVANCED_AUDITOR_ADMIN_PASS"));

        }
        else if (userRole.equalsIgnoreCase("StarterConverterHRAgent")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STARTER_CONVERTER_AGENT_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STARTER_CONVERTER_AGENT_PASS"));

        }
        else if (userRole.equalsIgnoreCase("StandardConverterHRAgent")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STANDARD_CONVERTER_AGENT_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STANDARD_CONVERTER_AGENT_PASS"));

        }
        else if (userRole.equalsIgnoreCase("AdvancedConverterHRAgent")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_ADVANCED_CONVERTER_AGENT_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_ADVANCED_CONVERTER_AGENT_PASS"));

        }
        else if (userRole.equalsIgnoreCase("StarterConverterHRAdmin")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STARTER_CONVERTER_ADMIN_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STARTER_CONVERTER_ADMIN_PASS"));

        }
        else if (userRole.equalsIgnoreCase("StandardConverterHRAdmin")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STANDARD_CONVERTER_ADMIN_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_STANDARD_CONVERTER_ADMIN_PASS"));

        }
        else if (userRole.equalsIgnoreCase("AdvancedConverterHRAdmin")){

            USERNAME = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_ADVANCED_CONVERTER_ADMIN_KEY"));
            PASSWORD = getSecret(getVaultConnection(), I9RescueDriverUtil.prop.getProperty("VAULT_SECRETKEYPATH"),
                    I9RescueDriverUtil.prop.getProperty("VAULT_I9INSPECT_ADVANCED_CONVERTER_ADMIN_PASS"));

        }
        else {

            log.error("Invalid user Role");
            Assert.assertTrue(false);
        }

    }




   public static Vault getVaultConnection() {

    Vault vault = null;
    try {
        String vaultToken = System.getProperty("vaultToken")==null? I9RescueDriverUtil.prop.getProperty("VAULT_TOKEN"):System.getProperty("vaultToken");

        final VaultConfig config = new VaultConfig().address(I9RescueDriverUtil.prop.getProperty("VAULT_ADDR")).
            nameSpace(I9RescueDriverUtil.prop.getProperty("VAULT_NAMESPACE")).token(vaultToken).build();


        vault = new Vault(config);

    } catch (VaultException e) {
        e.printStackTrace();
        System.out.println("Exception thrown: " + e);
    }

    return vault;
}

public static String getSecret(Vault vault, String secretKeyPath,String secretKey) {

    String keyValue = null;
    try {

        keyValue = vault.logical()
            .read(secretKeyPath)
            .getData().get(secretKey);

    } catch (VaultException e) {
        e.printStackTrace();
        System.out.println("Exception thrown: " + e);
    }
    return keyValue;
}

}
