package com.equifax.ews.utilities;

import com.google.common.base.Function;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

/**
 * This class deals with selenium utility.
 * <p>
 * Created by SESA459879 on 5/8/2017.
 */
public class SeleniumUtils {

    private static final Logger logger = LoggerFactory.getLogger(SeleniumUtils.class);
    public static WebDriver driver;
    public int maxRetry;
    public int explicitWait;
    public int pageRefreshWait;
    public int waitInMilliSec;
    public int refreshWaitInMilliSec;
    public int alertWaitInMilliSec;
    private String readyState = "return document";
    private String complete = "complete";


    public SeleniumUtils(Properties properties) {
        maxRetry = Integer.parseInt(properties.getProperty("maxRetry"));
        explicitWait = Integer.parseInt(properties.getProperty("10")); // PropertyConstants.EXPLICIT_WAIT
        pageRefreshWait = Integer.parseInt(properties.getProperty("10")); // PropertyConstants.PAGE_REFRESH_WAIT
        waitInMilliSec = Integer.parseInt(properties.getProperty("10")); // PropertyConstants.WAIT_IN_MILLI_SEC
        alertWaitInMilliSec = Integer.parseInt(properties.getProperty("10")); // PropertyConstants.ALERT_WAIT_IN_MILLI_SEC
        refreshWaitInMilliSec = Integer.parseInt(properties.getProperty("10")); // PropertyConstants.REFRESH_WAIT_IN_MILLI_SEC
    }



    /**
     * Find element with given parameter.
     */
    public WebElement findElement(WebDriver driver, Identifier identifier, String locator) {
        By by = getByLocator(identifier, locator);
        return driver.findElement(by);
    }

    /**
     * Find all element with given parameter.
     */
    public List<WebElement> findElements(WebDriver driver, Identifier identifier, String locator) {
        By by = getByLocator(identifier, locator);
        return driver.findElements(by);
    }

    public By getByLocator(Identifier identifier, String locator) {
        By by = null;
        switch (identifier) {
            case ID:
                by = By.id(locator);
                break;
            case NAME:
                by = By.name(locator);
                break;
            case CLASS_NAME:
                by = By.className(locator);
                break;
            case CSS:
                by = By.cssSelector(locator);
                break;
            case XPATH:
                by = By.xpath(locator);
                break;
        }
        return by;
    }

    /**
     * Send text key to webelement. Clear the text before sending the key.
     */
    public void sendKeys(WebElement webElement, String text) {
        webElement.clear();
        waitElementValueTextEmpty(webElement, pageRefreshWait, ChronoUnit.SECONDS);
        webElement.sendKeys(text);
    }

    public boolean waitForElementDisplay(WebDriver driver, WebElement webElement) {
        return waitForElementDisplay(driver, webElement, explicitWait);
    }

    /**
     * Waits until given element is displayed.
     */
    public boolean waitForElementDisplay(WebDriver driver, WebElement webElement, int timeOut) {
        try {
            Wait<WebElement> wait = new FluentWait<WebElement>(webElement).withTimeout(Duration.ofSeconds(timeOut))
                    .ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until((Function<WebElement, Boolean>) WebElement::isDisplayed);
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Waits until given element is displayed.
     */
    public boolean waitForElementDisplay(WebDriver driver, Identifier identifier, String locator) {
        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(explicitWait))
                    .ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until((ExpectedCondition<Boolean>) driver1 -> findElement(driver1, identifier, locator).isDisplayed());
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Waits till text in the element is not empty then returns the test.
     */
    public String getElementTextDisplay(WebDriver driver, Identifier identifier, String locator) {
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(explicitWait))
                .ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
        wait.until((ExpectedCondition<Boolean>) driver1 -> {
            String text = findElement(driver1, identifier, locator).getText();
            return null != text && !text.isEmpty();
        });
        return findElement(driver, identifier, locator).getText();
    }

    /**
     * Waits till text in the element is not empty then returns the test.
     */
    public boolean waitElementValueTextDisplay(WebElement element) {
        try {
            new FluentWait<>(element).withTimeout(Duration.ofSeconds(explicitWait))
                    .ignoring(NoSuchElementException.class).ignoring(WebDriverException.class)
                    .until((Function<WebElement, Boolean>) element1 -> {
                        String text = element1.getAttribute("value"); // "value"
                        return null != text && !text.isEmpty();
                    });
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Waits till text in the element is empty then returns the test.
     */
    public boolean waitElementValueTextEmpty(WebElement element, int timeOut, ChronoUnit chronoUnit) {
        try {
            new FluentWait<WebElement>(element).withTimeout(Duration.of(timeOut, chronoUnit)).ignoring(NoSuchElementException.class)
                    .ignoring(WebDriverException.class).until((Function<WebElement, Boolean>) element1 -> {
                String text = element1.getAttribute("value"); // "value"
                return null == text || text.isEmpty();
            });
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Waits till given element is clickable.
     */
    public boolean waitForElementClickable(WebDriver driver, WebElement webElement) {
        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(explicitWait))
                    .ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until(ExpectedConditions.elementToBeClickable(webElement));
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Waits till given element is clickable.
     */
    public boolean waitForElementClickable(WebDriver driver, Identifier identifier, String locator) {
        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(explicitWait))
                    .ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until(ExpectedConditions.elementToBeClickable(getByLocator(identifier, locator)));
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Waits until page is loaded.
     */
    public void waitForPageLoad(WebDriver driver) {
        WebDriverWait wait = new WebDriverWait(driver, explicitWait);
        wait.until((ExpectedCondition<Boolean>) driver1 -> ((JavascriptExecutor) driver1).executeScript(readyState).equals(complete));
    }

    /**
     * Waits until only one element is found for the given locator.
     */
    public boolean waitForSingleElementVisibility(WebDriver driver, Identifier identifier, String locator) {
        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(pageRefreshWait))
                    .ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until((ExpectedCondition<Boolean>) driver1 -> {
                List<WebElement> results = findElements(driver1, identifier, locator);
                return null != results && !results.isEmpty() && results.size() == 1;
            });
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public boolean waitFor(WebDriver driver, int timeout, ChronoUnit chronoUnit) {
        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.of(timeout, chronoUnit))
                    .ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until((ExpectedCondition<Boolean>) driver1 -> !((JavascriptExecutor) driver1).executeScript(readyState)
                    .equals(complete));
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * Waits till page refresh is triggered.
     */
    public void waitForPageRefresh(WebDriver driver) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, pageRefreshWait);
            wait.until((ExpectedCondition<Boolean>) driver1 -> !((JavascriptExecutor) driver1).executeScript(readyState)
                    .equals(complete));
        } catch (TimeoutException e) {
            logger.info("Connection timed out", e);
        }
    }

    /**
     * Clicks on a Button waiting until that it is clickable.
     */
    public boolean waitClickElement(WebDriver driver, Identifier identifier, String locator) {
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(explicitWait))
                .ignoring(NoSuchElementException.class).ignoring(WebDriverException.class)
                .ignoring(ElementNotVisibleException.class);
        wait.until((ExpectedCondition<Boolean>) driver1 -> {
            findElement(driver1, identifier, locator).click();
            return true;
        });
        return true;
    }

    /**
     * Clicks on a Button waiting until that it is clickable.
     */
    public boolean waitClickElement(WebElement webElement) {
        new FluentWait<WebElement>(webElement).withTimeout(Duration.ofSeconds(explicitWait))
                .ignoring(NoSuchElementException.class).ignoring(WebDriverException.class)
                .ignoring(ElementNotVisibleException.class).ignoring(TimeoutException.class)
                .until((Function<WebElement, Boolean>) element -> {
                    element.click();
                    return true;
                });
        return true;
    }

    public void implicitlyWait(int timeOut, TimeUnit timeUnit) {
        driver.manage().timeouts().implicitlyWait(timeOut, timeUnit);
    }

    public void scrollIntoView(WebDriver driver, WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }

    public void scrollUp() {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(0, -250);");
    }

    public void scrollDown() {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(0, 250);");
    }

    public void moveToElementClick(WebDriver driver, WebElement element) {
        Actions actions = new Actions(driver);
        actions.moveToElement(element).click().perform();
    }

    public void moveToElement(WebDriver driver, WebElement element) {
        Actions actions = new Actions(driver);
        actions.moveToElement(element).perform();
    }

    public void selectByValueFromDropDown(WebElement element, String value) {
        Select selectFromDropDown = new Select(element);
        selectFromDropDown.selectByValue(value);
    }

    public void selectByVisibleTextFromDropDown(WebElement element, String value) {
        Select selectFromDropDown = new Select(element);
        selectFromDropDown.selectByVisibleText(value);
    }

    public void selectByIndexFromDropDown(WebElement element, int index) {
        Select selectFromDropDown = new Select(element);
        selectFromDropDown.selectByIndex(index);
    }

    public boolean isAlertPresent(WebDriver driver) {
        try {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e) {
            return false;
        }
    }

    public void zoomOut(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.body.style.zoom='80%'");
    }

    public void zoomIn(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.body.style.zoom='100%'");
    }

    public enum Identifier {
        ID, NAME, CLASS_NAME, CSS, XPATH
    }
}
